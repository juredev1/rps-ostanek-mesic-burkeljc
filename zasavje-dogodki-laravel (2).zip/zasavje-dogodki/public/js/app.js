// Dogodki Zasavje – majhne izboljšave vmesnika.
// Vse deluje tudi brez JavaScripta; ta datoteka samo olajša uporabo.
document.documentElement.classList.add('js');

document.addEventListener('DOMContentLoaded', () => {
  // 1) Pokaži / skrij geslo (ikona oko)
  document.querySelectorAll('[data-toggle-password]').forEach((btn) => {
    const input = document.getElementById(btn.dataset.togglePassword);
    btn.addEventListener('click', () => {
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.setAttribute('aria-pressed', String(show));
      btn.setAttribute('aria-label', show ? 'Skrij geslo' : 'Pokaži geslo');
      btn.querySelector('use').setAttribute('href', btn.querySelector('use').getAttribute('href').replace(/#.*/, show ? '#eye-off' : '#eye'));
    });
  });

  // 2) Pravila gesla in moč gesla (enaka pravila kot na strežniku)
  document.querySelectorAll('[data-password-rules]').forEach((list) => {
    const input = document.getElementById(list.dataset.passwordRules);
    const meter = document.querySelector(`[data-password-strength="${input.id}"]`);
    const checks = {
      length: (v) => v.length >= 8,
      letter: (v) => /\p{L}/u.test(v),
      number: (v) => /\d/.test(v),
    };
    const update = () => {
      const v = input.value;
      let passed = 0;
      list.querySelectorAll('[data-rule]').forEach((li) => {
        const ok = checks[li.dataset.rule](v);
        li.classList.toggle('ok', ok);
        if (ok) passed++;
      });
      if (!meter) return;
      // Močno: vsa pravila + vsaj 12 znakov; Srednje: vsa pravila; Šibko: drugače
      const level = v === '' ? 0 : passed < 3 ? 1 : v.length >= 12 ? 3 : 2;
      meter.dataset.level = level;
      meter.querySelector('[data-label]').textContent =
        ['', 'Šibko geslo', 'Srednje močno geslo', 'Močno geslo'][level];
    };
    input.addEventListener('input', update);
    update();
  });

  // 3) Obrazec v korakih (Objavi dogodek: Naprej / Nazaj)
  document.querySelectorAll('[data-steps]').forEach((form) => {
    const steps = [...form.querySelectorAll('.step')];
    const progress = document.querySelectorAll('[data-step-progress] span');
    const label = document.querySelector('[data-step-label]');
    const show = (i) => {
      steps.forEach((s, k) => { s.hidden = k !== i; });
      progress.forEach((p, k) => p.classList.toggle('done', k <= i));
      if (label) label.textContent = `Korak ${i + 1} od ${steps.length}`;
      document.querySelectorAll('[data-step-only]').forEach((el) => {
        el.hidden = Number(el.dataset.stepOnly) !== i + 1;
      });
      window.scrollTo({ top: 0 });
    };
    document.querySelectorAll('[data-step-next]').forEach((b) => b.addEventListener('click', () => {
      const current = steps.findIndex((s) => !s.hidden);
      // preveri obvezna polja trenutnega koraka, preden gre naprej
      const invalid = [...steps[current].querySelectorAll('input, select, textarea')].find((el) => !el.checkValidity());
      if (invalid) { invalid.reportValidity(); return; }
      show(current + 1);
    }));
    document.querySelectorAll('[data-step-back]').forEach((b) => b.addEventListener('click', () => {
      show(Math.max(0, steps.findIndex((s) => !s.hidden) - 1));
    }));
    show(Number(form.dataset.startStep || 1) - 1);
  });

  // 4) Deli dogodek (sistemski meni za deljenje ali kopiranje povezave)
  document.querySelectorAll('[data-share]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const data = { title: btn.dataset.shareTitle, url: btn.dataset.share };
      try {
        if (navigator.share) { await navigator.share(data); return; }
        await navigator.clipboard.writeText(data.url);
        btn.setAttribute('aria-label', 'Povezava kopirana');
        btn.classList.add('copied');
        const toast = document.querySelector('[data-share-toast]');
        if (toast) { toast.hidden = false; setTimeout(() => { toast.hidden = true; }, 2500); }
      } catch (e) { /* uporabnik je preklical */ }
    });
  });

  // 5) Samodejno shranjevanje stikal (obvestila)
  document.querySelectorAll('[data-autosubmit]').forEach((form) => {
    form.addEventListener('change', () => form.requestSubmit());
    form.querySelectorAll('[data-autosubmit-hide]').forEach((el) => { el.hidden = true; });
  });
});
