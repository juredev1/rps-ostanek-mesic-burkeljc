# Dogodki Zasavje

Spletna aplikacija s skupnim koledarjem vseh lokalnih dogodkov v Zasavju (Trbovlje, Hrastnik, Zagorje ob Savi).
Uporabnik vidi, kaj se dogaja danes in ta vikend, filtrira po kraju in vrsti dogodka ter se dogodku pridruži.
Organizator po prijavi v nekaj korakih objavi svoj dogodek.

Ekipa: Jure Ostanek, Matic Burkeljc, Harun Mešić · Mentor: Žan Rajšek

## Tehnologije

- PHP 8.2+ in [Laravel 12](https://laravel.com/docs/12.x)
- Blade predloge, navaden CSS (`public/css/app.css`) po vizualnem slogu ekipe
- Pisavi Poppins in Inter (v `public/fonts`, brez nalaganja z Googla), ikone Lucide (`public/icons.svg`)
- Podatkovna baza: MySQL (npr. XAMPP s phpMyAdmin)
- Git + GitHub

## Zagon

Potrebuješ PHP 8.2+, [Composer](https://getcomposer.org), MySQL in Git. Najlažje je z XAMPP (PHP + MySQL + phpMyAdmin) in Composerjem.

1. V XAMPP Control Panel zaženi **Apache** in **MySQL**.
2. V phpMyAdmin (http://localhost/phpmyadmin) ustvari bazo `zasavje_dogodki` z naborom `utf8mb4_unicode_ci`.
3. V mapi projekta zaženi:

```bash
git clone <naslov-repozitorija>
cd zasavje-dogodki
composer install
cp .env.example .env          # na Windows: copy .env.example .env
php artisan key:generate
php artisan migrate --seed    # ustvari bazo in testne dogodke
php artisan serve
```

Aplikacija se odpre na http://localhost:8000.

Nastavitve baze so v datoteki `.env` (privzeto uporabnik `root` brez gesla, kot pri XAMPP):

```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=zasavje_dogodki
DB_USERNAME=root
DB_PASSWORD=
```

Testni račun: `organizator@example.com`, geslo `geslo123`.
Bazo s svežimi testnimi podatki ponastaviš z `php artisan migrate:fresh --seed`.

> Če bazo že imaš, zadošča `php artisan migrate`: preimenuje vrsti Koncert → Glasba in Drugo → Prireditev
> ter uporabnikom doda domači kraj in nastavitve obvestil. Za sveže testne podatke uporabi `php artisan migrate:fresh --seed`.

## Testi

```bash
php artisan test
```

Testi tečejo na začasni bazi v pomnilniku (SQLite), zato ne spreminjajo podatkov v MySQL.

52 testov v štirih datotekah:

- `tests/Feature/AuthTest.php` – registracija (tudi domači kraj), prijava, odjava, zgoščena gesla, pravila gesel, omejitev poskusov prijave
- `tests/Feature/AccountTest.php` – stran Moj račun, domači kraj in interesi, sprememba gesla, izbris računa
- `tests/Feature/EventTest.php` – ogled, filtri (kraj, vrsta, brezplačni, domači kraj), objava v dveh korakih, pridružitev, vrnitev na dogodek po prijavi, brisanje, datoteka za koledar
- `tests/Feature/MyEventsTest.php` – Moji dogodki (pridružen/a, objavljeni) in nastavitve obvestil

## Vizualni slog in zasloni

Videz sledi dokumentu »Dogodki Zasavje – vizualni slog« in žičnim skicam (prva različica).

| Zaslon | Pot | Kaj vsebuje |
| --- | --- | --- |
| Prijava | `/prijava` | e-pošta in geslo z ikonama, prikaz gesla, »Nadaljuj brez prijave« |
| Registracija | `/registracija` | ime, e-pošta, geslo z merilnikom moči, kraj, interesi, pogoji uporabe |
| Domov | `/` | Danes / Ta vikend / Vsi, čipi za kraj in vrsto, kartice dogodkov, spodnja navigacija |
| Podrobnosti | `/dogodki/{id}` | barva in ikona kategorije, datum, ura, kraj, cena, udeleženci, »Pridružim se« |
| Objavi dogodek | `/dogodki/nov` | dva koraka (Naprej / Nazaj), ločena datum in ura |
| Moji dogodki | `/moji-dogodki` | Pridružen/a / Objavljeni, stikali Opomnik in Novi dogodki |
| Moj račun | `/racun` | profil, domači kraj, interesi, geslo, odjava, izbris računa |

Barve so v `public/css/app.css` zapisane kot spremenljivke (`--oranzna`, `--tekst`, `--zelenomodra` …),
barve in ikone kategorij pa v `App\Models\Category::STYLES`. Ikono vstaviš z `<x-icon name="map-pin" />`.
Na mestu slike dogodka je zaenkrat barvna ploskev z ikono kategorije (nalaganje slik še ni narejeno).
Stikali za obvestila se shranita v bazo, pošiljanje obvestil pa še ni narejeno.

## Podatkovni model

ER-diagram je v `docs/er-diagram.png`, izvorno besedilo pa v `docs/er-diagram.mmd`
(urejaš ga na https://mermaid.live).

| Tabela | Namen |
| --- | --- |
| `users` | uporabniški računi (geslo samo zgoščeno z bcrypt), domači kraj, nastavitve obvestil |
| `events` | dogodki; tuji ključi `user_id`, `town_id`, `category_id` |
| `towns` | šifrant krajev |
| `categories` | šifrant vrst dogodkov |
| `event_user` | pridružitve (M:N med uporabniki in dogodki) |
| `category_user` | interesi uporabnika (M:N med uporabniki in vrstami) |
| `sessions` | seje prijavljenih uporabnikov in gostov |

## Varnost računov

- Gesla se shranijo zgoščena z algoritmom bcrypt (cast `hashed` v modelu `User`), nikoli kot čisto besedilo.
- Pravila za geslo (vsaj 8 znakov, črka in številka, največ 72) so na enem mestu v `AppServiceProvider`.
- Po 5 neuspešnih prijavah v minuti se prijava za isto e-pošto in IP začasno zaklene (`LoginRequest`).
- Po prijavi se ustvari nov ID seje, ob odjavi se seja izbriše; vsi obrazci imajo žeton CSRF.
- Napaka pri prijavi ne razkrije, ali račun z vpisano e-pošto obstaja.
- Sprememba gesla in izbris računa zahtevata trenutno geslo.

## Struktura (naše datoteke)

```
routes/web.php                                 vse poti (URL-ji) aplikacije
app/Models/Event.php                           model dogodka, filtri Danes / Ta vikend / kraj / vrsta
app/Models/User.php                            uporabnik, objavljeni in pridruženi dogodki, interesi
app/Models/Town.php, Category.php              šifranta krajev in vrst dogodkov
app/Http/Controllers/EventController.php       seznam, prikaz, objava, brisanje, datoteka .ics
app/Http/Controllers/AttendanceController.php  Pridružim se / preklic
app/Http/Controllers/Auth/                     registracija, prijava, odjava
app/Http/Requests/Auth/                        preverjanje obrazcev za registracijo in prijavo, omejitev poskusov
app/Http/Controllers/AccountController.php     Moj račun: domači kraj, interesi, sprememba gesla, izbris računa
app/Http/Controllers/MyEventsController.php    Moji dogodki in nastavitve obvestil
app/Http/Requests/StoreEventRequest.php        preverjanje obrazca Objavi dogodek (datum + ura)
app/Providers/AppServiceProvider.php           pravila za gesla
database/migrations/                           tabele users, towns, categories, events, event_user, category_user
database/seeders/DatabaseSeeder.php            testni podatki
resources/views/                               Blade predloge (layouts, events, auth, partials)
public/css/app.css                             vizualni slog (barve, pisave, gumbi, polja, kartice)
public/js/app.js                               prikaz gesla, moč gesla, koraki obrazca, deljenje
public/icons.svg, public/fonts/                ikone Lucide (ISC) ter pisavi Poppins in Inter (OFL)
resources/views/components/icon.blade.php      komponenta <x-icon>
lang/sl/                                       slovenska sporočila o napakah
docs/                                          ER-diagram
tests/Feature/                                 testi
```

## Poti

| Metoda | URL | Opis | Prijava |
| --- | --- | --- | --- |
| GET | `/` | Seznam dogodkov (`?view=today/weekend/all`, `town`, `category`, `free`) | ne |
| GET | `/dogodki/{id}` | Podrobnosti dogodka | ne |
| GET | `/dogodki/{id}/koledar.ics` | Dodaj v koledar (opomnik 1 uro prej) | ne |
| GET/POST | `/registracija`, `/prijava` | Ustvari račun, prijava | ne |
| POST | `/odjava` | Odjava | da |
| GET | `/racun` | Moj račun | da |
| PUT | `/racun/nastavitve` | Shrani domači kraj in interese | da |
| GET | `/moji-dogodki` | Moji dogodki (`?tab=objavljeni`) | da |
| PUT | `/moji-dogodki/obvestila` | Shrani nastavitve obvestil | da |
| PUT | `/racun/geslo` | Spremeni geslo (zahteva trenutno geslo) | da |
| DELETE | `/racun` | Izbriši račun (zahteva geslo) | da |
| GET | `/dogodki/nov` | Obrazec za objavo | da |
| POST | `/dogodki` | Shrani dogodek | da |
| DELETE | `/dogodki/{id}` | Izbriši (samo avtor) | da |
| POST/DELETE | `/dogodki/{id}/pridruzi` | Pridružim se / preklic | da |

## Delo z Gitom

- `main` je vedno delujoča različica.
- Za vsako funkcionalnost nova veja, npr. `feature/zemljevid`, nato pull request in pregled sošolca.
- Kratka sporočila commitov v slovenščini, npr. `Dodan filter po kraju`.
- Datoteke `.env` in mape `vendor/` ne nalagamo na GitHub (sta v `.gitignore`).
