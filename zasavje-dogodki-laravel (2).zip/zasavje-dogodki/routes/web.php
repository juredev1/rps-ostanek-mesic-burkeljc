<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\MyEventsController;
use Illuminate\Support\Facades\Route;

// Javno: ogled dogodkov brez prijave
Route::get('/', [EventController::class, 'index'])->name('events.index');

// Samo za neprijavljene (prijavljenega uporabnika preusmeri na začetno stran)
Route::middleware('guest')->group(function () {
    Route::get('/registracija', [RegisterController::class, 'create'])->name('register');
    Route::post('/registracija', [RegisterController::class, 'store'])->middleware('throttle:6,1'); // največ 6 registracij na minuto z enega IP-ja
    Route::get('/prijava', [LoginController::class, 'create'])->name('login');
    Route::post('/prijava', [LoginController::class, 'store']); // omejitev poskusov je v LoginRequest
});

// Samo za prijavljene
Route::middleware('auth')->group(function () {
    Route::post('/odjava', [LoginController::class, 'destroy'])->name('logout');

    Route::get('/racun', [AccountController::class, 'show'])->name('account.show');
    Route::put('/racun/nastavitve', [AccountController::class, 'updatePreferences'])->name('account.preferences');

    Route::get('/moji-dogodki', [MyEventsController::class, 'index'])->name('my-events');
    Route::put('/moji-dogodki/obvestila', [MyEventsController::class, 'updateNotifications'])->name('my-events.notifications');
    Route::put('/racun/geslo', [AccountController::class, 'updatePassword'])->name('account.password');
    Route::delete('/racun', [AccountController::class, 'destroy'])->name('account.destroy');

    Route::get('/dogodki/nov', [EventController::class, 'create'])->name('events.create');
    Route::post('/dogodki', [EventController::class, 'store'])->name('events.store');
    Route::delete('/dogodki/{event}', [EventController::class, 'destroy'])->name('events.destroy');

    Route::post('/dogodki/{event}/pridruzi', [AttendanceController::class, 'store'])->name('events.join');
    Route::delete('/dogodki/{event}/pridruzi', [AttendanceController::class, 'destroy'])->name('events.leave');
});

// Javno: podrobnosti dogodka in "Dodaj v koledar" (cilj QR kode na plakatu)
Route::get('/dogodki/{event}', [EventController::class, 'show'])->name('events.show');
Route::get('/dogodki/{event}/koledar.ics', [EventController::class, 'calendar'])->name('events.calendar');
