{{--
    Postavitev aplikacije.
    @section('shell') določi vrsto zaslona:
      app    – glava z logotipom in »+ Objavi« ter spodnja navigacija (privzeto)
      page   – podstran z lastno zgornjo vrstico (nazaj) in po želji spodnjo vrstico z gumbom (@section('actionbar'))
      auth   – prijava in registracija (brez navigacije)
--}}
@php($shell = trim($__env->yieldContent('shell')) ?: 'app')
<!doctype html>
<html lang="sl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="description" content="Vsi lokalni dogodki v Zasavju na enem mestu">
    <meta name="theme-color" content="#C2410C">
    <title>@yield('title', 'Dogodki Zasavje')</title>
    <link rel="icon" href="{{ asset('favicon.svg') }}" type="image/svg+xml">
    {{-- Pisavi Poppins (naslovi) in Inter (besedilo) sta v public/fonts --}}
    <link rel="preload" href="{{ asset('fonts/inter-latin-400-normal.woff2') }}" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="{{ asset('fonts/poppins-latin-600-normal.woff2') }}" as="font" type="font/woff2" crossorigin>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <script src="{{ asset('js/app.js') }}" defer></script>
</head>
<body class="shell-{{ $shell }} @hasSection('actionbar') has-actionbar @endif">
    <div class="app">
        @if ($shell === 'app')
            <header class="topbar">
                <a href="{{ route('events.index') }}" class="logo">
                    <span class="logo__mark"><x-icon name="calendar-check" size="20" /></span>
                    Dogodki Zasavje
                </a>
                <a href="{{ route('events.create') }}" class="btn btn--primary btn--small">
                    <x-icon name="plus" /> Objavi
                </a>
            </header>
        @endif

        {{-- Na podstraneh (shell page) pogled sam prikaže obvestilo pod zgornjo vrstico --}}
        @if ($shell !== 'page')
            @include('partials.toast')
        @endif

        <main>
            @yield('content')
        </main>
    </div>

    @hasSection('actionbar')
        <div class="actionbar">
            <div class="actionbar__inner">@yield('actionbar')</div>
        </div>
    @endif

    @if ($shell === 'app')
        @include('partials.bottom-nav')
    @endif
</body>
</html>
