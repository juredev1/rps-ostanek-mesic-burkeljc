@extends('layouts.app')

@section('title', 'Moj račun – Dogodki Zasavje')

@section('content')
    <h1>Moj račun</h1>

    <section class="card card--section" aria-labelledby="profil">
        <h2 id="profil" class="h3">Profil</h2>
        <dl class="info-list">
            <dt>Ime in priimek</dt><dd>{{ $user->name }}</dd>
            <dt>E-pošta</dt><dd>{{ $user->email }}</dd>
            <dt>Domači kraj</dt><dd>{{ $user->town?->name ?? 'ni izbran' }}</dd>
            <dt>Registriran/a od</dt><dd>{{ $user->created_at->format('j. n. Y') }}</dd>
            <dt>Objavljeni dogodki</dt><dd>{{ $user->events_count }}</dd>
            <dt>Pridružitve</dt><dd>{{ $user->joined_events_count }}</dd>
        </dl>
    </section>

    <h2 class="section-title"><x-icon name="sliders-horizontal" /> Nastavitve</h2>
    <form method="POST" action="{{ route('account.preferences') }}" class="card card--section">
        @csrf
        @method('PUT')
        <div class="field">
            <label class="field__label" for="town_id">Domači kraj</label>
            <div class="control control--select">
                <x-icon name="map-pin" />
                <select class="select" id="town_id" name="town_id">
                    <option value="">Brez (pokaži vse kraje)</option>
                    @foreach ($towns as $town)
                        <option value="{{ $town->id }}" @selected($user->town_id === $town->id)>{{ $town->name }}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <fieldset class="chip-group">
            <legend>Interesi</legend>
            @foreach ($categories as $category)
                <input type="checkbox" class="chip-input" name="interests[]" id="int-{{ $category->id }}" value="{{ $category->id }}" @checked(in_array($category->id, $interestIds))>
                <label class="chip" for="int-{{ $category->id }}">
                    <x-icon :name="$category->icon()" size="16" class="cat-icon--{{ $category->styleKey() }}" /> {{ $category->name }}
                </label>
            @endforeach
        </fieldset>
        <div><button class="btn btn--primary btn--small">Shrani nastavitve</button></div>
    </form>

    <h2 class="section-title"><x-icon name="lock" /> Spremeni geslo</h2>
    <form method="POST" action="{{ route('account.password') }}" class="card card--section" novalidate>
        @csrf
        @method('PUT')
        <div class="field @error('current_password', 'updatePassword') is-invalid @enderror">
            <label class="field__label" for="current_password">Trenutno geslo</label>
            <input class="input" type="password" id="current_password" name="current_password" autocomplete="current-password" required>
            @error('current_password', 'updatePassword') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
        </div>
        <div class="field @error('password', 'updatePassword') is-invalid @enderror">
            <label class="field__label" for="new_password">Novo geslo</label>
            <input class="input" type="password" id="new_password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required>
            <ul class="pw-rules" data-password-rules="new_password">
                <li data-rule="length"><x-icon name="check" size="16" class="icon-ok" /><x-icon name="x" size="16" class="icon-no" /> Vsaj 8 znakov</li>
                <li data-rule="letter"><x-icon name="check" size="16" class="icon-ok" /><x-icon name="x" size="16" class="icon-no" /> Vsaj ena črka</li>
                <li data-rule="number"><x-icon name="check" size="16" class="icon-ok" /><x-icon name="x" size="16" class="icon-no" /> Vsaj ena številka</li>
            </ul>
            @error('password', 'updatePassword') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
        </div>
        <div class="field">
            <label class="field__label" for="new_password_confirmation">Ponovi novo geslo</label>
            <input class="input" type="password" id="new_password_confirmation" name="password_confirmation" maxlength="72" autocomplete="new-password" required>
        </div>
        <div><button class="btn btn--primary btn--small">Spremeni geslo</button></div>
    </form>

    <h2 class="section-title"><x-icon name="log-out" /> Odjava</h2>
    <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button class="btn btn--tertiary btn--block"><x-icon name="log-out" /> Odjava</button>
    </form>

    <h2 class="section-title"><x-icon name="trash-2" /> Izbriši račun</h2>
    <form method="POST" action="{{ route('account.destroy') }}" class="card card--section" novalidate
          onsubmit="return confirm('Res izbrišem račun? Izbrisani bodo tudi tvoji dogodki in pridružitve.')">
        @csrf
        @method('DELETE')
        <p class="text-secondary" style="margin:0">Izbrišejo se vsi tvoji podatki: račun, objavljeni dogodki, pridružitve in interesi.</p>
        <div class="field @error('password', 'deleteAccount') is-invalid @enderror">
            <label class="field__label" for="delete_password">Za potrditev vpiši geslo</label>
            <input class="input" type="password" id="delete_password" name="password" autocomplete="current-password" required>
            @error('password', 'deleteAccount') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
        </div>
        <div><button class="btn btn--danger btn--small"><x-icon name="trash-2" /> Izbriši račun</button></div>
    </form>
@endsection
