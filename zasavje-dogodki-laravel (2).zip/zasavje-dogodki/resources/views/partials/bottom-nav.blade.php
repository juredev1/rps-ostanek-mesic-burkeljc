{{-- Spodnja navigacija (4 zavihki, kot na žični skici) --}}
<nav class="bottomnav" aria-label="Glavna navigacija">
    <div class="bottomnav__inner">
        <a href="{{ route('events.index') }}" @if (request()->routeIs('events.index')) aria-current="page" @endif>
            <x-icon name="calendar" size="24" /> Dogodki
        </a>
        <a href="{{ route('events.create') }}" @if (request()->routeIs('events.create')) aria-current="page" @endif>
            <x-icon name="plus" size="24" /> Objavi
        </a>
        <a href="{{ route('my-events') }}" @if (request()->routeIs('my-events')) aria-current="page" @endif>
            <x-icon name="bookmark" size="24" /> Moji dogodki
        </a>
        @auth
            <a href="{{ route('account.show') }}" @if (request()->routeIs('account.*')) aria-current="page" @endif>
                <x-icon name="user" size="24" /> Račun
            </a>
        @else
            <a href="{{ route('login') }}">
                <x-icon name="user" size="24" /> Prijava
            </a>
        @endauth
    </div>
</nav>
