@if (session('status'))
    <p class="toast" role="status"><x-icon name="circle-check" /> {{ session('status') }}</p>
@endif
