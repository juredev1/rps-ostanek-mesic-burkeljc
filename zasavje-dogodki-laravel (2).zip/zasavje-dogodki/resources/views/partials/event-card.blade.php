{{-- Kartica dogodka (osnovni element vizualnega sloga) --}}
<a href="{{ route('events.show', $event) }}" class="event-card">
    <div class="date-badge" aria-hidden="true">
        <span class="date-badge__day">{{ $event->badgeDay() }}</span>
        <span class="date-badge__month">{{ $event->badgeMonth() }}</span>
    </div>
    <div class="event-card__body">
        <h3 class="event-card__title">{{ $event->title }}</h3>
        <span class="visually-hidden">{{ $event->starts_at->translatedFormat('l, j. F') }}</span>
        <span class="meta"><x-icon name="clock" size="16" /> {{ $event->starts_at->format('H:i') }}</span>
        <span class="meta"><x-icon name="map-pin" size="16" /> {{ $event->town->name }} · {{ $event->location }}</span>
        <div class="badges">
            <span class="badge badge--{{ $event->category->styleKey() }}">
                <x-icon :name="$event->category->icon()" size="14" /> {{ $event->category->name }}
            </span>
            @if ($event->is_free)
                <span class="badge badge--free">Brezplačno</span>
            @endif
            @if ($event->isJoinedBy(auth()->user()))
                <span class="badge badge--joined"><x-icon name="check" size="14" /> Pridružen/a</span>
            @endif
        </div>
        <span class="meta meta--teal"><x-icon name="users" size="16" /> {{ \App\Support\Sl::attendees($event->attendees_count) }}</span>
    </div>
</a>
