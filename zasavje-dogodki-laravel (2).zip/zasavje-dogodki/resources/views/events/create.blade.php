@extends('layouts.app')

@section('shell', 'page')
@section('title', 'Objavi dogodek – Dogodki Zasavje')

@php
    // Če je napaka samo v poljih 2. koraka, odpremo obrazec na 2. koraku
    $stepOneFields = ['title', 'category_id', 'date', 'time', 'starts_at', 'town_id', 'description'];
    $startStep = $errors->hasAny(\App\Http\Requests\StoreEventRequest::STEP_TWO_FIELDS) && ! $errors->hasAny($stepOneFields) ? 2 : 1;
@endphp

@section('content')
    <div class="pagebar">
        <a href="{{ route('events.index') }}" class="icon-btn" aria-label="Zapri"><x-icon name="x" /></a>
        <h1 class="pagebar__title">Objavi dogodek</h1>
        <span class="pagebar__step" data-step-label>Korak {{ $startStep }} od 2</span>
    </div>
    @include('partials.toast')
    <div class="steps-progress" data-step-progress aria-hidden="true"><span class="done"></span><span class="{{ $startStep === 2 ? 'done' : '' }}"></span></div>

    <form method="POST" action="{{ route('events.store') }}" id="event-form" class="form" data-steps data-start-step="{{ $startStep }}" novalidate>
        @csrf

        {{-- 1. korak: kaj, kdaj, kje --}}
        <div class="step form">
            <div class="field @error('title') is-invalid @enderror">
                <label class="field__label" for="title">Naslov</label>
                <input class="input" id="title" name="title" value="{{ old('title') }}" maxlength="80" required placeholder="npr. Koncert v Delavskem domu">
                @error('title') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            </div>

            <fieldset class="chip-group @error('category_id') is-invalid @enderror">
                <legend>Vrsta</legend>
                @foreach ($categories as $category)
                    <input type="radio" class="chip-input" name="category_id" id="cat-{{ $category->id }}" value="{{ $category->id }}"
                           @checked((int) old('category_id', $loop->first ? $category->id : 0) === $category->id) required>
                    <label class="chip" for="cat-{{ $category->id }}">
                        <x-icon :name="$category->icon()" size="16" class="cat-icon--{{ $category->styleKey() }}" /> {{ $category->name }}
                    </label>
                @endforeach
            </fieldset>
            @error('category_id') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror

            <div class="row-2">
                <div class="field @error('date') is-invalid @enderror @error('starts_at') is-invalid @enderror">
                    <label class="field__label" for="date">Datum</label>
                    <input class="input" type="date" id="date" name="date" value="{{ old('date') }}" min="{{ today()->format('Y-m-d') }}" required>
                </div>
                <div class="field @error('time') is-invalid @enderror @error('starts_at') is-invalid @enderror">
                    <label class="field__label" for="time">Ura</label>
                    <input class="input" type="time" id="time" name="time" value="{{ old('time') }}" required>
                </div>
            </div>
            @foreach (['date', 'time', 'starts_at'] as $field)
                @error($field) <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            @endforeach

            <div class="field @error('town_id') is-invalid @enderror">
                <label class="field__label" for="town_id">Kraj</label>
                <div class="control control--select">
                    <select class="select" id="town_id" name="town_id" required>
                        @foreach ($towns as $town)
                            <option value="{{ $town->id }}" @selected((int) old('town_id', auth()->user()->town_id) === $town->id)>{{ $town->name }}</option>
                        @endforeach
                    </select>
                </div>
                @error('town_id') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            </div>

            <div class="field @error('description') is-invalid @enderror">
                <label class="field__label" for="description">Opis <span class="optional">(neobvezno)</span></label>
                <textarea class="textarea" id="description" name="description" maxlength="500" placeholder="Kaj se bo dogajalo, komu je namenjeno …">{{ old('description') }}</textarea>
                @error('description') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            </div>
        </div>

        {{-- 2. korak: lokacija, organizator, vstopnina --}}
        <div class="step form">
            <div class="field @error('location') is-invalid @enderror">
                <label class="field__label" for="location">Lokacija</label>
                <div class="control">
                    <x-icon name="map-pin" />
                    <input class="input" id="location" name="location" value="{{ old('location') }}" maxlength="120" required placeholder="npr. Delavski dom Trbovlje">
                </div>
                @error('location') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            </div>

            <div class="field @error('organizer') is-invalid @enderror">
                <label class="field__label" for="organizer">Organizator</label>
                <div class="control">
                    <x-icon name="users" />
                    <input class="input" id="organizer" name="organizer" value="{{ old('organizer', auth()->user()->name) }}" maxlength="80" required>
                </div>
                <span class="field__hint">Društvo, klub ali tvoje ime.</span>
                @error('organizer') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            </div>

            <label class="switch-row">
                <x-icon name="circle-euro" class="switch-row__icon" />
                <span class="switch-row__text"><strong>Brezplačen vstop</strong><span class="text-secondary">Dogodek bo označen kot brezplačen.</span></span>
                <input type="checkbox" class="switch" name="is_free" value="1" @checked(old('is_free'))>
            </label>
        </div>
    </form>
@endsection

@section('actionbar')
    <button type="button" class="btn btn--primary js-only" data-step-next data-step-only="1">Naprej <x-icon name="chevron-right" /></button>
    <button type="button" class="btn btn--tertiary js-only" data-step-back data-step-only="2" hidden><x-icon name="arrow-left" /> Nazaj</button>
    {{-- Brez JavaScripta sta vidna oba koraka in gumb Objavi --}}
    <button type="submit" form="event-form" class="btn btn--primary" data-step-only="2">Objavi dogodek</button>
@endsection
