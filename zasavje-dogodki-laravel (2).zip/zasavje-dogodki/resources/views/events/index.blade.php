@extends('layouts.app')

@section('content')
    <h1 class="visually-hidden">Dogodki v Zasavju</h1>

    {{-- Danes / Ta vikend / Vsi --}}
    <nav class="segmented" aria-label="Obdobje">
        @foreach (['today' => 'Danes', 'weekend' => 'Ta vikend', 'all' => 'Vsi'] as $key => $label)
            <a href="{{ route('events.index', array_merge($query, ['view' => $key])) }}"
               @if ($view === $key) aria-current="page" @endif>{{ $label }}</a>
        @endforeach
    </nav>

    {{-- Kraj --}}
    <nav class="chips" aria-label="Kraj">
        <a class="chip" href="{{ route('events.index', array_merge($query, ['town' => 'vsi'])) }}"
           @if (! $filters['town']) aria-current="true" @endif>
            <x-icon name="map-pin" size="16" /> Vsi kraji
        </a>
        @foreach ($towns as $town)
            <a class="chip" href="{{ route('events.index', array_merge($query, ['town' => $town->id])) }}"
               @if ($filters['town'] === $town->id) aria-current="true" @endif>{{ $town->name }}</a>
        @endforeach
    </nav>

    {{-- Vrsta dogodka in brezplačni --}}
    <nav class="chips" aria-label="Vrsta dogodka">
        <a class="chip" href="{{ route('events.index', \Illuminate\Support\Arr::except($query, 'category')) }}"
           @if (empty($filters['category'])) aria-current="true" @endif>Vse vrste</a>
        @foreach ($categories as $category)
            <a class="chip" href="{{ route('events.index', array_merge($query, ['category' => $category->id])) }}"
               @if ((int) ($filters['category'] ?? 0) === $category->id) aria-current="true" @endif>
                <x-icon :name="$category->icon()" size="16" class="cat-icon--{{ $category->styleKey() }}" /> {{ $category->name }}
            </a>
        @endforeach
        @if (! empty($filters['free']))
            <a class="chip" aria-current="true" href="{{ route('events.index', \Illuminate\Support\Arr::except($query, 'free')) }}">
                <x-icon name="circle-euro" size="16" /> Brezplačni
            </a>
        @else
            <a class="chip" href="{{ route('events.index', array_merge($query, ['free' => 1])) }}">
                <x-icon name="circle-euro" size="16" /> Brezplačni
            </a>
        @endif
    </nav>

    <p class="result-count" aria-live="polite">{{ \App\Support\Sl::events($events->count()) }}</p>

    @if ($events->isEmpty())
        <div class="empty">
            <x-icon name="calendar" size="32" />
            <p>Za izbrane pogoje ni dogodkov.</p>
            <a href="{{ route('events.index', ['view' => 'all', 'town' => 'vsi']) }}" class="btn btn--tertiary btn--small">Pokaži vse dogodke</a>
        </div>
    @else
        <div class="event-list">
            @foreach ($events as $event)
                @include('partials.event-card', ['event' => $event])
            @endforeach
        </div>
    @endif
@endsection
