@extends('layouts.app')

@section('shell', 'page')
@section('title', $event->title.' – Dogodki Zasavje')

@section('content')
    <div class="pagebar">
        <a href="{{ url()->previous() !== url()->current() ? url()->previous() : route('events.index') }}" class="icon-btn" aria-label="Nazaj">
            <x-icon name="arrow-left" />
        </a>
        <span class="pagebar__title"></span>
        <button type="button" class="icon-btn" data-share="{{ route('events.show', $event) }}" data-share-title="{{ $event->title }}" aria-label="Deli dogodek">
            <x-icon name="share-2" />
        </button>
    </div>
    @include('partials.toast')
    <p class="toast" data-share-toast hidden role="status"><x-icon name="check" /> Povezava je kopirana.</p>

    {{-- Mesto za sliko dogodka: dokler slik ne nalagamo, pokažemo barvo in ikono kategorije --}}
    <div class="hero hero--{{ $event->category->styleKey() }}" aria-hidden="true">
        <x-icon :name="$event->category->icon()" size="64" />
    </div>

    <span class="badge badge--{{ $event->category->styleKey() }}">
        <x-icon :name="$event->category->icon()" size="14" /> {{ $event->category->name }}
    </span>
    <h1 style="margin-top: 8px">{{ $event->title }}</h1>
    <p class="text-secondary">Organizator: {{ $event->organizer }}</p>

    <div class="card facts">
        <span class="meta"><x-icon name="calendar" /> {{ $event->starts_at->translatedFormat('l, j. F Y') }}</span>
        <span class="meta"><x-icon name="clock" /> {{ $event->starts_at->format('H:i') }}</span>
        <span class="meta"><x-icon name="map-pin" /> {{ $event->location }}, {{ $event->town->name }}</span>
        <span class="meta"><x-icon name="circle-euro" /> {{ $event->is_free ? 'Brezplačno' : 'Plačljivo' }}</span>
        <span class="meta meta--teal"><x-icon name="users" /> {{ \App\Support\Sl::attendees($event->attendees_count) }}</span>
    </div>

    @if ($event->description)
        <h2>O dogodku</h2>
        <p>{{ $event->description }}</p>
    @endif

    <div class="detail-actions">
        <a href="{{ route('events.calendar', $event) }}" class="btn btn--secondary btn--small">
            <x-icon name="calendar-plus" /> Dodaj v koledar
        </a>
        @if (auth()->id() === $event->user_id)
            <form method="POST" action="{{ route('events.destroy', $event) }}" onsubmit="return confirm('Res izbrišem dogodek?')">
                @csrf
                @method('DELETE')
                <button class="btn btn--danger btn--small"><x-icon name="trash-2" /> Izbriši dogodek</button>
            </form>
        @endif
    </div>
@endsection

@section('actionbar')
    @auth
        @if ($event->isJoinedBy(auth()->user()))
            <span class="joined-state"><x-icon name="check" /> Pridružen/a</span>
            <form method="POST" action="{{ route('events.leave', $event) }}">
                @csrf
                @method('DELETE')
                <button class="btn btn--tertiary">Prekliči</button>
            </form>
        @else
            <form method="POST" action="{{ route('events.join', $event) }}">
                @csrf
                <button class="btn btn--primary"><x-icon name="users" /> Pridružim se</button>
            </form>
        @endif
    @else
        <a href="{{ route('login', ['nazaj' => '/dogodki/'.$event->id]) }}" class="btn btn--primary"><x-icon name="users" /> Pridružim se</a>
    @endauth
@endsection
