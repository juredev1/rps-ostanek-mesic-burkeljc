{{-- Ikona iz public/icons.svg (Lucide, črtne, debelina 2 px). Primer: <x-icon name="map-pin" /> --}}
@props(['name', 'size' => 20])
<svg {{ $attributes->merge(['class' => 'icon']) }} width="{{ $size }}" height="{{ $size }}" aria-hidden="true" focusable="false"><use href="{{ asset('icons.svg') }}#{{ $name }}"></use></svg>
