@extends('layouts.app')

@section('title', 'Moji dogodki – Dogodki Zasavje')

@section('content')
    <h1>Moji dogodki</h1>

    <nav class="segmented" aria-label="Moji dogodki">
        <a href="{{ route('my-events') }}" @if ($tab === 'pridruzen') aria-current="page" @endif>Pridružen/a</a>
        <a href="{{ route('my-events', ['tab' => 'objavljeni']) }}" @if ($tab === 'objavljeni') aria-current="page" @endif>Objavljeni</a>
    </nav>

    @if ($events->isEmpty())
        <div class="empty">
            <x-icon name="bookmark" size="32" />
            @if ($tab === 'objavljeni')
                <p>Še nisi objavil/a nobenega dogodka.</p>
                <a href="{{ route('events.create') }}" class="btn btn--primary btn--small"><x-icon name="plus" /> Objavi dogodek</a>
            @else
                <p>Še nisi pridružen/a nobenemu prihajajočemu dogodku.</p>
                <a href="{{ route('events.index', ['view' => 'all']) }}" class="btn btn--tertiary btn--small">Poišči dogodke</a>
            @endif
        </div>
    @else
        <p class="result-count">{{ \App\Support\Sl::events($events->count()) }}</p>
        <div class="event-list">
            @foreach ($events as $event)
                @include('partials.event-card', ['event' => $event])
            @endforeach
        </div>
    @endif

    <h2 class="section-title"><x-icon name="bell" /> Obvestila</h2>
    <form method="POST" action="{{ route('my-events.notifications') }}" class="form" style="gap:8px" data-autosubmit>
        @csrf
        @method('PUT')
        <label class="switch-row">
            <x-icon name="bell-ring" class="switch-row__icon" />
            <span class="switch-row__text">
                <strong>Opomnik</strong>
                <span class="text-secondary">Dan pred dogodkom, ki si se mu pridružil/a.</span>
            </span>
            <input type="checkbox" class="switch" name="notify_reminders" value="1" @checked($user->notify_reminders)>
        </label>
        <label class="switch-row">
            <x-icon name="bell" class="switch-row__icon" />
            <span class="switch-row__text">
                <strong>Novi dogodki</strong>
                <span class="text-secondary">Ko je objavljen nov dogodek{{ $user->town ? ' v kraju '.$user->town->name : ' v tvojem kraju' }}.</span>
            </span>
            <input type="checkbox" class="switch" name="notify_new_events" value="1" @checked($user->notify_new_events)>
        </label>
        <p class="text-secondary" style="margin:0">Nastavitve se shranijo takoj. Pošiljanje obvestil po e-pošti pripravljamo.</p>
        <button class="btn btn--tertiary btn--small" data-autosubmit-hide>Shrani nastavitve</button>
    </form>
@endsection
