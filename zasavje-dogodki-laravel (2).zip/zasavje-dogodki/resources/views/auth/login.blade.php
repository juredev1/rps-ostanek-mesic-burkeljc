@extends('layouts.app')

@section('shell', 'auth')
@section('title', 'Prijava – Dogodki Zasavje')

@section('content')
    <div class="auth">
        <div class="auth__head">
            <a href="{{ route('events.index') }}" class="logo logo--large">
                <span class="logo__mark"><x-icon name="calendar-check" size="32" /></span>
                Dogodki Zasavje
            </a>
            <h1>Prijava</h1>
            <p class="text-secondary">Prijavi se, da se pridružiš dogodkom in objaviš svoje.</p>
        </div>

        <form method="POST" action="{{ route('login') }}" class="form" novalidate>
            @csrf

            <div class="field @error('email') is-invalid @enderror">
                <label class="field__label" for="email">E-pošta</label>
                <div class="control">
                    <x-icon name="mail" />
                    <input class="input" type="email" id="email" name="email" value="{{ old('email') }}"
                           autocomplete="email" required autofocus placeholder="ime@primer.si">
                </div>
                @error('email') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            </div>

            <div class="field @error('password') is-invalid @enderror">
                <label class="field__label" for="password">Geslo</label>
                <div class="control control--end">
                    <x-icon name="lock" />
                    <input class="input" type="password" id="password" name="password" autocomplete="current-password" required>
                    <button type="button" class="icon-btn control__end js-only" data-toggle-password="password" aria-label="Pokaži geslo" aria-pressed="false">
                        <x-icon name="eye" />
                    </button>
                </div>
                @error('password') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            </div>

            <label class="check"><input type="checkbox" name="remember" value="1"> Zapomni si me</label>

            <button class="btn btn--primary btn--block">Prijava</button>
            <a href="{{ route('events.index') }}" class="btn btn--tertiary btn--block">Nadaljuj brez prijave</a>
        </form>

        <p class="auth__foot">Še nimaš računa? <a href="{{ route('register') }}">Registriraj se</a></p>
    </div>
@endsection
