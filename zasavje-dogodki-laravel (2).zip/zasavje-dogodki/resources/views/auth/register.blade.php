@extends('layouts.app')

@section('shell', 'auth')
@section('title', 'Registracija – Dogodki Zasavje')

@section('content')
    <div class="auth">
        <div class="auth__head">
            <a href="{{ route('events.index') }}" class="logo logo--large">
                <span class="logo__mark"><x-icon name="calendar-check" size="32" /></span>
                Dogodki Zasavje
            </a>
            <h1>Ustvari račun</h1>
            <p class="text-secondary">Račun potrebuješ za objavo dogodkov in pridružitev. Dogodke si lahko ogledaš tudi brez računa.</p>
        </div>

        {{-- novalidate: preverjanje izvede strežnik (RegisterRequest), da so sporočila vedno v slovenščini --}}
        <form method="POST" action="{{ route('register') }}" class="form" novalidate>
            @csrf

            <div class="field @error('name') is-invalid @enderror">
                <label class="field__label" for="name">Ime in priimek</label>
                <div class="control">
                    <x-icon name="user" />
                    <input class="input" id="name" name="name" value="{{ old('name') }}" maxlength="80" autocomplete="name" required autofocus>
                </div>
                @error('name') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            </div>

            <div class="field @error('email') is-invalid @enderror">
                <label class="field__label" for="email">E-pošta</label>
                <div class="control">
                    <x-icon name="mail" />
                    <input class="input" type="email" id="email" name="email" value="{{ old('email') }}" maxlength="120" autocomplete="email" required placeholder="ime@primer.si">
                </div>
                @error('email') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            </div>

            <div class="field @error('password') is-invalid @enderror">
                <label class="field__label" for="password">Geslo</label>
                <div class="control control--end">
                    <x-icon name="lock" />
                    <input class="input" type="password" id="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required aria-describedby="pw-rules">
                    <button type="button" class="icon-btn control__end js-only" data-toggle-password="password" aria-label="Pokaži geslo" aria-pressed="false">
                        <x-icon name="eye" />
                    </button>
                </div>
                <ul class="pw-rules" id="pw-rules" data-password-rules="password">
                    <li data-rule="length"><x-icon name="check" size="16" class="icon-ok" /><x-icon name="x" size="16" class="icon-no" /> Vsaj 8 znakov</li>
                    <li data-rule="letter"><x-icon name="check" size="16" class="icon-ok" /><x-icon name="x" size="16" class="icon-no" /> Vsaj ena črka</li>
                    <li data-rule="number"><x-icon name="check" size="16" class="icon-ok" /><x-icon name="x" size="16" class="icon-no" /> Vsaj ena številka</li>
                </ul>
                <div class="pw-strength js-only" data-password-strength="password" data-level="0">
                    <span class="pw-strength__bar"><span></span></span><span data-label></span>
                </div>
                @error('password') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            </div>

            <div class="field">
                <label class="field__label" for="password_confirmation">Ponovi geslo</label>
                <div class="control">
                    <x-icon name="lock" />
                    <input class="input" type="password" id="password_confirmation" name="password_confirmation" maxlength="72" autocomplete="new-password" required>
                </div>
            </div>

            <div class="field @error('town_id') is-invalid @enderror">
                <label class="field__label" for="town_id">Kraj <span class="optional">(neobvezno)</span></label>
                <div class="control control--select">
                    <x-icon name="map-pin" />
                    <select class="select" id="town_id" name="town_id">
                        <option value="">Izberi svoj kraj</option>
                        @foreach ($towns as $town)
                            <option value="{{ $town->id }}" @selected((int) old('town_id') === $town->id)>{{ $town->name }}</option>
                        @endforeach
                    </select>
                </div>
                <span class="field__hint">Na začetni strani ti bomo najprej pokazali dogodke v tvojem kraju.</span>
                @error('town_id') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            </div>

            <fieldset class="chip-group">
                <legend>Kaj te zanima? <span class="optional">(neobvezno)</span></legend>
                @foreach ($categories as $category)
                    <input type="checkbox" class="chip-input" name="interests[]" id="int-{{ $category->id }}" value="{{ $category->id }}"
                           @checked(in_array($category->id, old('interests', [])))>
                    <label class="chip" for="int-{{ $category->id }}">
                        <x-icon :name="$category->icon()" size="16" class="cat-icon--{{ $category->styleKey() }}" /> {{ $category->name }}
                    </label>
                @endforeach
            </fieldset>
            @error('interests.*') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror

            <div class="field @error('terms') is-invalid @enderror">
                <label class="check">
                    <input type="checkbox" name="terms" value="1" @checked(old('terms'))>
                    <span>Strinjam se s pogoji uporabe in obdelavo osebnih podatkov.</span>
                </label>
                @error('terms') <span class="field__error"><x-icon name="circle-alert" size="16" /> {{ $message }}</span> @enderror
            </div>

            <button class="btn btn--primary btn--block">Ustvari račun</button>
        </form>

        <p class="auth__foot">Že imaš račun? <a href="{{ route('login') }}">Prijavi se</a></p>
    </div>
@endsection
