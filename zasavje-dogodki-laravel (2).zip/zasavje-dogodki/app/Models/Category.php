<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** Vrsta dogodka (šifrant): Glasba, Šport, Razstava, Delavnica, Prostovoljstvo, Prireditev */
class Category extends Model
{
    /** Barva (razred CSS) in ikona Lucide za vsako vrsto – po vizualnem slogu */
    public const STYLES = [
        'Glasba' => ['key' => 'glasba', 'icon' => 'music'],
        'Šport' => ['key' => 'sport', 'icon' => 'trophy'],
        'Razstava' => ['key' => 'razstava', 'icon' => 'palette'],
        'Delavnica' => ['key' => 'delavnica', 'icon' => 'hammer'],
        'Prostovoljstvo' => ['key' => 'prostovoljstvo', 'icon' => 'hand-heart'],
        'Prireditev' => ['key' => 'prireditev', 'icon' => 'party-popper'],
    ];

    public $timestamps = false;

    protected $fillable = ['name'];

    public function events(): HasMany
    {
        return $this->hasMany(Event::class);
    }

    /** Uporabniki, ki so to vrsto dogodkov izbrali med interese */
    public function interestedUsers(): BelongsToMany
    {
        return $this->belongsToMany(User::class);
    }

    /** Ključ barve, npr. "glasba" → razredi badge--glasba, hero--glasba */
    public function styleKey(): string
    {
        return self::STYLES[$this->name]['key'] ?? 'prireditev';
    }

    public function icon(): string
    {
        return self::STYLES[$this->name]['icon'] ?? 'calendar';
    }
}
