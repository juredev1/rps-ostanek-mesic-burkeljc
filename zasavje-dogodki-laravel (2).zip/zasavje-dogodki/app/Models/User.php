<?php

namespace App\Models;

use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    /**
     * Polja, ki jih lahko nastavimo z ::create() / ->update().
     * Polji id in remember_token namenoma nista na seznamu.
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'town_id',
        'terms_accepted_at',
        'notify_reminders',
        'notify_new_events',
    ];

    /** Ta polja se nikoli ne izpišejo (npr. pri pretvorbi v JSON) */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'terms_accepted_at' => 'datetime',
            'notify_reminders' => 'boolean',
            'notify_new_events' => 'boolean',
            // 'hashed': geslo se ob shranjevanju samodejno zgosti z algoritmom bcrypt
            'password' => 'hashed',
        ];
    }

    /** Domači kraj (neobvezno) – privzeti filter na začetni strani */
    public function town(): BelongsTo
    {
        return $this->belongsTo(Town::class);
    }

    /** Dogodki, ki jih je uporabnik objavil (1:N) */
    public function events(): HasMany
    {
        return $this->hasMany(Event::class);
    }

    /** Dogodki, ki se jim je uporabnik pridružil (M:N prek event_user) */
    public function joinedEvents(): BelongsToMany
    {
        return $this->belongsToMany(Event::class)->withTimestamps();
    }

    /** Vrste dogodkov, ki uporabnika zanimajo (M:N prek category_user) */
    public function interests(): BelongsToMany
    {
        return $this->belongsToMany(Category::class);
    }
}
