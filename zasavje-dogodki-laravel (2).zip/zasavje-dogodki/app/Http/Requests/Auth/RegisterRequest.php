<?php

namespace App\Http\Requests\Auth;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password;

/**
 * Preverjanje podatkov iz registracijskega obrazca.
 * Sporočila o napakah so v lang/sl/validation.php.
 */
class RegisterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // registrira se lahko vsak neprijavljen obiskovalec
    }

    /** Pred preverjanjem: odstrani presledke, e-pošto zapiši z malimi črkami */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'name' => trim((string) $this->input('name')),
            'email' => Str::lower(trim((string) $this->input('email'))),
        ]);
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'min:2', 'max:80'],
            'email' => ['required', 'string', 'email:rfc,filter_unicode', 'max:120', 'unique:users,email'], // filter: zahteva domeno s piko (npr. .si)
            'password' => ['required', 'string', 'confirmed', Password::defaults()],
            'town_id' => ['nullable', 'integer', 'exists:towns,id'],
            'interests' => ['nullable', 'array'],
            'interests.*' => ['integer', 'distinct', 'exists:categories,id'],
            'terms' => ['accepted'],
        ];
    }
}
