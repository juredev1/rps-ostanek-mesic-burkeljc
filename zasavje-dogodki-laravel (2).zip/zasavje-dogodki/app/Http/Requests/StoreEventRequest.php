<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

/**
 * Preverjanje obrazca »Objavi dogodek«.
 * Datum in uro uporabnik vnese ločeno (kot na žični skici), v bazo pa se shranita skupaj v starts_at.
 */
class StoreEventRequest extends FormRequest
{
    /** Polja drugega koraka – ob napaki v njih se obrazec odpre na 2. koraku */
    public const STEP_TWO_FIELDS = ['location', 'organizer', 'is_free'];

    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    protected function prepareForValidation(): void
    {
        $date = (string) $this->input('date');
        $time = (string) $this->input('time');

        $this->merge([
            'title' => trim((string) $this->input('title')),
            'starts_at' => $date !== '' && $time !== '' ? $date.' '.$time : null,
        ]);
    }

    public function rules(): array
    {
        return [
            'title' => ['required', 'string', 'max:80'],
            'category_id' => ['required', 'integer', 'exists:categories,id'],
            'date' => ['required', 'date_format:Y-m-d'],
            'time' => ['required', 'date_format:H:i'],
            'starts_at' => ['nullable', 'date', 'after:now'],
            'town_id' => ['required', 'integer', 'exists:towns,id'],
            'description' => ['nullable', 'string', 'max:500'],
            'location' => ['required', 'string', 'max:120'],
            'organizer' => ['required', 'string', 'max:80'],
            'is_free' => ['nullable', 'boolean'],
        ];
    }

    /** Podatki, ki se shranijo v tabelo events */
    public function eventData(): array
    {
        $data = $this->safe()->only(['title', 'category_id', 'town_id', 'description', 'location', 'organizer']);
        $data['starts_at'] = $this->input('starts_at');
        $data['is_free'] = $this->boolean('is_free');

        return $data;
    }
}
