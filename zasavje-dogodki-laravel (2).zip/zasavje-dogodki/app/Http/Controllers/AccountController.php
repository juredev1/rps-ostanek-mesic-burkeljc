<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Town;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Password;
use Illuminate\View\View;

/** Stran "Moj račun": podatki, interesi, sprememba gesla in izbris računa */
class AccountController extends Controller
{
    public function show(Request $request): View
    {
        $user = $request->user()->load('town')->loadCount(['events', 'joinedEvents']);

        return view('account.show', [
            'user' => $user,
            'towns' => Town::orderBy('id')->get(),
            'categories' => Category::orderBy('id')->get(),
            'interestIds' => $user->interests()->pluck('categories.id')->all(),
        ]);
    }

    /** Domači kraj in interesi */
    public function updatePreferences(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'town_id' => ['nullable', 'integer', 'exists:towns,id'],
            'interests' => ['nullable', 'array'],
            'interests.*' => ['integer', 'distinct', 'exists:categories,id'],
        ]);

        $request->user()->update(['town_id' => $data['town_id'] ?? null]);
        $request->user()->interests()->sync($data['interests'] ?? []);

        return back()->with('status', 'Nastavitve so shranjene.');
    }

    public function updatePassword(Request $request): RedirectResponse
    {
        // Ločena "vreča" napak, da se napake ne pomešajo z obrazcem za izbris računa
        $data = $request->validateWithBag('updatePassword', [
            'current_password' => ['required', 'current_password'],
            'password' => ['required', 'string', 'confirmed', Password::defaults(), 'different:current_password'],
        ]);

        $request->user()->update(['password' => $data['password']]); // zgosti se samodejno
        $request->session()->regenerate();

        return back()->with('status', 'Geslo je spremenjeno.');
    }

    public function destroy(Request $request): RedirectResponse
    {
        $request->validateWithBag('deleteAccount', [
            'password' => ['required', 'current_password'],
        ]);

        $user = $request->user();

        Auth::logout();
        $user->delete(); // tuji ključi s CASCADE izbrišejo tudi njegove dogodke, pridružitve in interese

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('events.index')->with('status', 'Račun je izbrisan.');
    }
}
