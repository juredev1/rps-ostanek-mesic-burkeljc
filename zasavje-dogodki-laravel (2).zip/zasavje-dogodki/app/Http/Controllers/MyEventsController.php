<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** Zaslon »Moji dogodki«: dogodki, ki sem se jim pridružil/a, moji objavljeni dogodki in obvestila */
class MyEventsController extends Controller
{
    public function index(Request $request): View
    {
        $tab = $request->query('tab') === 'objavljeni' ? 'objavljeni' : 'pridruzen';
        $user = $request->user();

        $query = $tab === 'objavljeni' ? $user->events() : $user->joinedEvents();

        $events = $query
            ->upcoming()
            ->with(['town', 'category'])
            ->withCount('attendees')
            ->with(['attendees' => fn ($q) => $q->whereKey($user->id)])
            ->orderBy('starts_at')
            ->get();

        return view('my-events.index', [
            'tab' => $tab,
            'events' => $events,
            'user' => $user,
        ]);
    }

    /** Stikali »Opomnik« in »Novi dogodki« */
    public function updateNotifications(Request $request): RedirectResponse
    {
        $request->user()->update([
            'notify_reminders' => $request->boolean('notify_reminders'),
            'notify_new_events' => $request->boolean('notify_new_events'),
        ]);

        return back()->with('status', 'Nastavitve obvestil so shranjene.');
    }
}
