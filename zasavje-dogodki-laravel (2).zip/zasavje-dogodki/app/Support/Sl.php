<?php

namespace App\Support;

/** Pomožne funkcije za slovenski jezik */
class Sl
{
    /**
     * Slovenska množina: 1 dogodek, 2 dogodka, 3 dogodki, 5 dogodkov (101 dogodek ...).
     *
     * @param  array{0:string,1:string,2:string,3:string}  $forms  ednina, dvojina, množina (3–4), množina (5+)
     */
    public static function plural(int $n, array $forms): string
    {
        $mod = $n % 100;
        $form = match (true) {
            $mod === 1 => $forms[0],
            $mod === 2 => $forms[1],
            $mod === 3, $mod === 4 => $forms[2],
            default => $forms[3],
        };

        return $n.' '.$form;
    }

    public static function events(int $n): string
    {
        return self::plural($n, ['dogodek', 'dogodka', 'dogodki', 'dogodkov']);
    }

    public static function attendees(int $n): string
    {
        return $n === 0 ? 'Še brez udeležencev' : self::plural($n, ['udeleženec', 'udeleženca', 'udeleženci', 'udeležencev']);
    }
}
