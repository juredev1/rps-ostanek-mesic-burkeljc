<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Town;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Testni podatki: en organizator in nekaj dogodkov.
     * Kraji in vrste dogodkov se vstavijo že v migracijah.
     * Datumi so relativni na današnji dan, da je v pogledih vedno kaj videti.
     * Zagon: php artisan migrate:fresh --seed
     */
    public function run(): void
    {
        $user = User::factory()->create([
            'name' => 'Testni Organizator',
            'email' => 'organizator@example.com',
            'password' => 'geslo123',  // shrani se zgoščeno (cast 'hashed' v modelu User)
        ]);

        $town = Town::pluck('id', 'name');          // ['Trbovlje' => 1, ...]
        $category = Category::pluck('id', 'name');  // ['Koncert' => 1, ...]

        $user->interests()->sync([$category['Glasba'], $category['Šport']]);
        $user->update(['town_id' => $town['Trbovlje']]);

        $saturday = today()->isSaturday() ? today() : today()->next(Carbon::SATURDAY);
        $at = fn (Carbon $day, int $hour) => $day->copy()->setTime($hour, 0);

        $events = [
            ['Koncert lokalnih skupin', 'Trbovlje', 'Delavski dom Trbovlje', 'Glasba', $at(today(), 20), 'Mladinski center', 'Večer lokalne glasbe.', false],
            ['Čistilna akcija ob Savi', 'Hrastnik', 'Most čez Savo', 'Prostovoljstvo', $at(today(), 18), 'Občina Hrastnik', 'Rokavice in vreče zagotovljene.', true],
            ['Razstava fotografij Zasavja', 'Hrastnik', 'Knjižnica Hrastnik', 'Razstava', $at(today()->addDay(), 18), 'Foto klub', 'Odprtje razstave.', true],
            ['Pohod na Kum', 'Trbovlje', 'Izhodišče Dobovec', 'Šport', $at($saturday, 8), 'PD Trbovlje', 'Lahek pohod za vse generacije.', true],
            ['Delavnica programiranja za mlade', 'Zagorje ob Savi', 'Kulturni dom Zagorje', 'Delavnica', $at($saturday->copy()->addDay(), 10), 'Društvo Tehnika', 'Uvod v izdelavo spletnih strani.', true],
            ['Nogometna tekma', 'Zagorje ob Savi', 'Stadion Zagorje', 'Šport', $at(today()->addDays(9), 17), 'NK Zagorje', 'Domača tekma.', false],
            ['Martinovanje na trgu', 'Zagorje ob Savi', 'Cesta 9. avgusta', 'Prireditev', $at($saturday, 17), 'TD Zagorje', 'Pokušina mladega vina, glasba v živo in stojnice lokalnih pridelovalcev.', true],
        ];

        foreach ($events as [$title, $townName, $location, $categoryName, $startsAt, $organizer, $description, $isFree]) {
            $user->events()->create([
                'title' => $title,
                'town_id' => $town[$townName],
                'location' => $location,
                'category_id' => $category[$categoryName],
                'starts_at' => $startsAt,
                'organizer' => $organizer,
                'description' => $description,
                'is_free' => $isFree,
            ]);
        }
    }
}
