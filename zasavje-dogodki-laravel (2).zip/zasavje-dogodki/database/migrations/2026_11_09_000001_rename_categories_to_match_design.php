<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    // Imena vrst dogodkov uskladimo z vizualnim slogom (Glasba, Šport, Razstava, Delavnica, Prostovoljstvo, Prireditev)
    private const RENAMES = [
        'Koncert' => 'Glasba',
        'Drugo' => 'Prireditev',
    ];

    public function up(): void
    {
        foreach (self::RENAMES as $old => $new) {
            DB::table('categories')->where('name', $old)->update(['name' => $new]);
        }
    }

    public function down(): void
    {
        foreach (self::RENAMES as $old => $new) {
            DB::table('categories')->where('name', $new)->update(['name' => $old]);
        }
    }
};
