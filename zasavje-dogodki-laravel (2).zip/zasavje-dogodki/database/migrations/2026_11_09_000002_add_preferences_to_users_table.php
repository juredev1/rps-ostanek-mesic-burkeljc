<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Domači kraj (registracija) in nastavitve obvestil (zaslon Moji dogodki)
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->foreignId('town_id')->nullable()->after('password')
                ->constrained()->nullOnDelete();                               // domači kraj, neobvezno
            $table->boolean('notify_reminders')->default(true)->after('terms_accepted_at');   // opomnik pred dogodkom
            $table->boolean('notify_new_events')->default(false)->after('notify_reminders');  // novi dogodki v mojem kraju
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropConstrainedForeignId('town_id');
            $table->dropColumn(['notify_reminders', 'notify_new_events']);
        });
    }
};
