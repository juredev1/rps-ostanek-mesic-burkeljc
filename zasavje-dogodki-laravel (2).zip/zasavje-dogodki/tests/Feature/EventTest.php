<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Event;
use App\Models\Town;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class EventTest extends TestCase
{
    use RefreshDatabase;

    private function makeEvent(User $user, array $overrides = []): Event
    {
        return $user->events()->create(array_merge([
            'title' => 'Testni dogodek',
            'town_id' => Town::where('name', 'Trbovlje')->value('id'),
            'location' => 'Delavski dom',
            'category_id' => Category::where('name', 'Glasba')->value('id'),
            'starts_at' => now()->addDays(2),
            'organizer' => 'Društvo',
            'is_free' => true,
        ], $overrides));
    }

    public function test_guest_can_see_events(): void
    {
        $this->makeEvent(User::factory()->create());

        $this->get('/?view=all')->assertOk()->assertSee('Testni dogodek');
    }

    public function test_events_can_be_filtered_by_town(): void
    {
        $user = User::factory()->create();
        $this->makeEvent($user, ['title' => 'Dogodek v Trbovljah']);
        $this->makeEvent($user, ['title' => 'Dogodek v Hrastniku', 'town_id' => Town::where('name', 'Hrastnik')->value('id')]);

        $hrastnik = Town::where('name', 'Hrastnik')->value('id');

        $this->get('/?view=all&town='.$hrastnik)
            ->assertOk()
            ->assertSee('Dogodek v Hrastniku')
            ->assertDontSee('Dogodek v Trbovljah');
    }

    public function test_event_with_unknown_town_is_rejected(): void
    {
        $this->actingAs(User::factory()->create())->post('/dogodki', [
            'title' => 'Dogodek',
            'town_id' => 999,
            'location' => 'Dom kulture',
            'category_id' => Category::first()->id,
            'date' => now()->addWeek()->format('Y-m-d'),
            'time' => '18:30',
            'organizer' => 'Klub',
        ])->assertSessionHasErrors('town_id');
    }

    public function test_logged_in_user_sees_home_town_first(): void
    {
        $trbovlje = Town::where('name', 'Trbovlje')->value('id');
        $hrastnik = Town::where('name', 'Hrastnik')->value('id');
        $author = User::factory()->create();
        $this->makeEvent($author, ['title' => 'Dogodek v Trbovljah']);
        $this->makeEvent($author, ['title' => 'Dogodek v Hrastniku', 'town_id' => $hrastnik]);

        $user = User::factory()->create(['town_id' => $hrastnik]);

        // brez izbranega kraja: domači kraj
        $this->actingAs($user)->get('/?view=all')
            ->assertSee('Dogodek v Hrastniku')
            ->assertDontSee('Dogodek v Trbovljah');

        // čip "Vsi kraji"
        $this->actingAs($user)->get('/?view=all&town=vsi')
            ->assertSee('Dogodek v Hrastniku')
            ->assertSee('Dogodek v Trbovljah');

        $this->assertNotNull($trbovlje);
    }

    public function test_events_can_be_filtered_by_category_and_free(): void
    {
        $author = User::factory()->create();
        $sport = Category::where('name', 'Šport')->value('id');
        $this->makeEvent($author, ['title' => 'Koncert zastonj']);
        $this->makeEvent($author, ['title' => 'Plačljiv pohod', 'category_id' => $sport, 'is_free' => false]);
        $this->makeEvent($author, ['title' => 'Brezplačen pohod', 'category_id' => $sport, 'is_free' => true]);

        $this->get('/?view=all&category='.$sport.'&free=1')
            ->assertSee('Brezplačen pohod')
            ->assertDontSee('Plačljiv pohod')
            ->assertDontSee('Koncert zastonj');
    }

    public function test_event_card_shows_date_badge_and_category(): void
    {
        $this->makeEvent(User::factory()->create(), ['starts_at' => now()->addDays(2)->setTime(19, 0)]);

        $this->get('/?view=all')
            ->assertSee('date-badge', false)
            ->assertSee('badge--glasba', false)
            ->assertSee('19:00');
    }

    public function test_create_form_has_two_steps_with_date_and_time(): void
    {
        $this->actingAs(User::factory()->create())->get('/dogodki/nov')
            ->assertOk()
            ->assertSee('name="date"', false)
            ->assertSee('name="time"', false)
            ->assertSee('Korak 1 od 2');
    }

    public function test_date_and_time_are_combined_into_start(): void
    {
        $user = User::factory()->create();
        $date = now()->addDays(3)->format('Y-m-d');

        $this->actingAs($user)->post('/dogodki', [
            'title' => 'Večerni koncert',
            'town_id' => Town::first()->id,
            'location' => 'Dom kulture',
            'category_id' => Category::first()->id,
            'date' => $date,
            'time' => '20:15',
            'organizer' => 'Klub',
        ])->assertSessionHasNoErrors();

        $this->assertSame($date.' 20:15', $user->events()->first()->starts_at->format('Y-m-d H:i'));
    }

    public function test_missing_step_two_field_reopens_step_two(): void
    {
        $this->actingAs(User::factory()->create())
            ->from('/dogodki/nov')
            ->followingRedirects()
            ->post('/dogodki', [
                'title' => 'Dogodek',
                'town_id' => Town::first()->id,
                'category_id' => Category::first()->id,
                'date' => now()->addDays(3)->format('Y-m-d'),
                'time' => '20:15',
                'organizer' => 'Klub',
            ])
            ->assertSee('data-start-step="2"', false)
            ->assertSee('Polje »lokacija« je obvezno.');
    }

    public function test_guest_join_button_returns_to_event_after_login(): void
    {
        $event = $this->makeEvent(User::factory()->create());
        User::factory()->create(['email' => 'ana@example.com', 'password' => 'skrivnost123']);

        $this->get('/dogodki/'.$event->id)->assertSee('/prijava?nazaj=', false);
        $this->get('/prijava?nazaj=/dogodki/'.$event->id);

        $this->post('/prijava', ['email' => 'ana@example.com', 'password' => 'skrivnost123'])
            ->assertRedirect('/dogodki/'.$event->id);
    }

    public function test_login_ignores_external_return_address(): void
    {
        User::factory()->create(['email' => 'ana@example.com', 'password' => 'skrivnost123']);

        $this->get('/prijava?nazaj=//zlobna-stran.si');
        $this->post('/prijava', ['email' => 'ana@example.com', 'password' => 'skrivnost123'])
            ->assertRedirect('/');
    }

    public function test_guest_cannot_open_create_form(): void
    {
        $this->get('/dogodki/nov')->assertRedirect('/prijava');
    }

    public function test_user_can_create_event(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->post('/dogodki', [
            'title' => 'Nov koncert',
            'town_id' => Town::where('name', 'Hrastnik')->value('id'),
            'location' => 'Dom kulture',
            'category_id' => Category::where('name', 'Glasba')->value('id'),
            'date' => now()->addWeek()->format('Y-m-d'),
            'time' => '18:30',
            'organizer' => 'Klub',
        ])->assertRedirect();

        $this->assertDatabaseHas('events', ['title' => 'Nov koncert', 'user_id' => $user->id]);
    }

    public function test_event_in_past_is_rejected(): void
    {
        $this->actingAs(User::factory()->create())->post('/dogodki', [
            'title' => 'Stari dogodek',
            'town_id' => Town::where('name', 'Hrastnik')->value('id'),
            'location' => 'Dom kulture',
            'category_id' => Category::where('name', 'Glasba')->value('id'),
            'date' => now()->subDay()->format('Y-m-d'),
            'time' => '18:30',
            'organizer' => 'Klub',
        ])->assertSessionHasErrors(['starts_at' => 'Dogodek mora biti v prihodnosti.']);
    }

    public function test_user_can_join_only_once(): void
    {
        $user = User::factory()->create();
        $event = $this->makeEvent($user);

        $this->actingAs($user)->post("/dogodki/{$event->id}/pridruzi");
        $this->actingAs($user)->post("/dogodki/{$event->id}/pridruzi");

        $this->assertSame(1, $event->attendees()->count());
    }

    public function test_only_author_can_delete_event(): void
    {
        $event = $this->makeEvent(User::factory()->create());

        $this->actingAs(User::factory()->create())
            ->delete("/dogodki/{$event->id}")
            ->assertForbidden();
    }

    public function test_calendar_file_has_reminder(): void
    {
        $event = $this->makeEvent(User::factory()->create());

        $this->get("/dogodki/{$event->id}/koledar.ics")
            ->assertOk()
            ->assertHeader('Content-Type', 'text/calendar; charset=utf-8')
            ->assertSee('TRIGGER:-PT1H');
    }
}
