<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Event;
use App\Models\Town;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class MyEventsTest extends TestCase
{
    use RefreshDatabase;

    private function makeEvent(User $author, string $title): Event
    {
        return $author->events()->create([
            'title' => $title,
            'town_id' => Town::first()->id,
            'category_id' => Category::first()->id,
            'location' => 'Dom',
            'starts_at' => now()->addDays(2),
            'organizer' => 'Društvo',
        ]);
    }

    public function test_guest_is_sent_to_login(): void
    {
        $this->get('/moji-dogodki')->assertRedirect('/prijava');
    }

    public function test_joined_tab_shows_only_joined_events(): void
    {
        $author = User::factory()->create();
        $joined = $this->makeEvent($author, 'Dogodek, ki se mu pridružim');
        $this->makeEvent($author, 'Drug dogodek');

        $user = User::factory()->create();
        $user->joinedEvents()->attach($joined);

        $this->actingAs($user)->get('/moji-dogodki')
            ->assertOk()
            ->assertSee('Dogodek, ki se mu pridružim')
            ->assertDontSee('Drug dogodek');
    }

    public function test_published_tab_shows_own_events(): void
    {
        $user = User::factory()->create();
        $this->makeEvent($user, 'Moj dogodek');
        $this->makeEvent(User::factory()->create(), 'Tuj dogodek');

        $this->actingAs($user)->get('/moji-dogodki?tab=objavljeni')
            ->assertOk()
            ->assertSee('Moj dogodek')
            ->assertDontSee('Tuj dogodek');
    }

    public function test_notification_settings_are_saved(): void
    {
        $user = User::factory()->create();
        $this->assertTrue($user->fresh()->notify_reminders);   // privzeto vklopljeno
        $this->assertFalse($user->fresh()->notify_new_events); // privzeto izklopljeno

        $this->actingAs($user)->put('/moji-dogodki/obvestila', ['notify_new_events' => '1'])
            ->assertSessionHasNoErrors();

        $user->refresh();
        $this->assertFalse($user->notify_reminders);
        $this->assertTrue($user->notify_new_events);
    }
}
