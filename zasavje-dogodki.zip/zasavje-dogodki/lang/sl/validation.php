<?php

// Slovenska sporočila o napakah pri preverjanju obrazcev (samo pravila, ki jih aplikacija uporablja).
return [
    'accepted' => 'Polje »:attribute« mora biti potrjeno.',
    'after' => 'Polje »:attribute« mora biti datum po :date.',
    'array' => 'Polje »:attribute« ni veljavno.',
    'boolean' => 'Polje »:attribute« mora biti da ali ne.',
    'confirmed' => 'Potrditev polja »:attribute« se ne ujema.',
    'current_password' => 'Geslo ni pravilno.',
    'date' => 'Polje »:attribute« mora biti veljaven datum.',
    'different' => 'Polji »:attribute« in »:other« morata biti različni.',
    'distinct' => 'Polje »:attribute« vsebuje podvojeno vrednost.',
    'email' => 'Vnesi veljaven e-poštni naslov.',
    'exists' => 'Izbrana vrednost polja »:attribute« ne obstaja.',
    'in' => 'Izbrana vrednost polja »:attribute« ni veljavna.',
    'integer' => 'Polje »:attribute« mora biti celo število.',
    'max' => [
        'array' => 'Polje »:attribute« ima lahko največ :max elementov.',
        'file' => 'Datoteka »:attribute« je lahko velika največ :max KB.',
        'numeric' => 'Polje »:attribute« je lahko največ :max.',
        'string' => 'Polje »:attribute« ima lahko največ :max znakov.',
    ],
    'min' => [
        'array' => 'Polje »:attribute« mora imeti vsaj :min elementov.',
        'file' => 'Datoteka »:attribute« mora biti velika vsaj :min KB.',
        'numeric' => 'Polje »:attribute« mora biti vsaj :min.',
        'string' => 'Polje »:attribute« mora imeti vsaj :min znakov.',
    ],
    'password' => [
        'letters' => 'Geslo mora vsebovati vsaj eno črko.',
        'mixed' => 'Geslo mora vsebovati vsaj eno veliko in eno malo črko.',
        'numbers' => 'Geslo mora vsebovati vsaj eno številko.',
        'symbols' => 'Geslo mora vsebovati vsaj en poseben znak.',
        'uncompromised' => 'To geslo se je pojavilo v uhajanju podatkov. Izberi drugo geslo.',
    ],
    'required' => 'Polje »:attribute« je obvezno.',
    'string' => 'Polje »:attribute« mora biti besedilo.',
    'unique' => 'Vrednost polja »:attribute« je že uporabljena.',

    // Sporočila za posamezna polja
    'custom' => [
        'email' => [
            'unique' => 'Račun s to e-pošto že obstaja.',
        ],
        'password' => [
            'confirmed' => 'Gesli se ne ujemata.',
            'different' => 'Novo geslo mora biti drugačno od trenutnega.',
        ],
        'terms' => [
            'accepted' => 'Za registracijo se moraš strinjati s pogoji uporabe in obdelavo osebnih podatkov.',
        ],
        'starts_at' => [
            'after' => 'Dogodek mora biti v prihodnosti.',
        ],
    ],

    // Imena polj, kot se izpišejo v sporočilih
    'attributes' => [
        'name' => 'ime in priimek',
        'email' => 'e-pošta',
        'password' => 'geslo',
        'current_password' => 'trenutno geslo',
        'terms' => 'soglasje',
        'interests' => 'interesi',
        'interests.*' => 'interes',
        'title' => 'naslov',
        'town_id' => 'kraj',
        'category_id' => 'vrsta',
        'location' => 'lokacija',
        'starts_at' => 'datum in ura',
        'organizer' => 'organizator',
        'description' => 'opis',
    ],
];
