<?php

return [
    // Enako sporočilo za napačno e-pošto ali napačno geslo (ne razkrije, ali račun obstaja)
    'failed' => 'E-pošta ali geslo ni pravilno.',
    'password' => 'Geslo ni pravilno.',
    'throttle' => 'Preveč neuspešnih poskusov prijave. Poskusi znova čez :seconds s.',
];
