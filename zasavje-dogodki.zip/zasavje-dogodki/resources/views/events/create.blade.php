@extends('layouts.app')

@section('title', 'Objavi dogodek – Dogodki Zasavje')

@section('content')
    <form method="POST" action="{{ route('events.store') }}" class="form">
        @csrf
        <h1>Objavi dogodek</h1>

        <label>Naslov
            <input name="title" value="{{ old('title') }}" maxlength="80" required>
            @error('title') <span class="error">{{ $message }}</span> @enderror
        </label>

        <label>Kraj
            <select name="town_id">
                @foreach ($towns as $town)
                    <option value="{{ $town->id }}" @selected(old('town_id') == $town->id)>{{ $town->name }}</option>
                @endforeach
            </select>
            @error('town_id') <span class="error">{{ $message }}</span> @enderror
        </label>

        <label>Lokacija
            <input name="location" value="{{ old('location') }}" placeholder="npr. Delavski dom" maxlength="120" required>
            @error('location') <span class="error">{{ $message }}</span> @enderror
        </label>

        <label>Vrsta
            <select name="category_id">
                @foreach ($categories as $category)
                    <option value="{{ $category->id }}" @selected(old('category_id') == $category->id)>{{ $category->name }}</option>
                @endforeach
            </select>
            @error('category_id') <span class="error">{{ $message }}</span> @enderror
        </label>

        <label>Datum in ura
            <input type="datetime-local" name="starts_at" value="{{ old('starts_at') }}" required>
            @error('starts_at') <span class="error">{{ $message }}</span> @enderror
        </label>

        <label>Organizator
            <input name="organizer" value="{{ old('organizer', auth()->user()->name) }}" maxlength="80" required>
            @error('organizer') <span class="error">{{ $message }}</span> @enderror
        </label>

        <label>Opis
            <textarea name="description" rows="3" maxlength="500">{{ old('description') }}</textarea>
            @error('description') <span class="error">{{ $message }}</span> @enderror
        </label>

        <label class="row">
            <input type="checkbox" name="is_free" value="1" @checked(old('is_free'))> Brezplačen vstop
        </label>

        <div class="row end">
            <a href="{{ route('events.index') }}" class="btn ghost">Prekliči</a>
            <button class="btn">Objavi</button>
        </div>
    </form>
@endsection
