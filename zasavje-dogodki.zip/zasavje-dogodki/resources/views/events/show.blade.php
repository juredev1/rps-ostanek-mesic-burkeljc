@extends('layouts.app')

@section('title', $event->title.' – Dogodki Zasavje')

@section('content')
    <a href="{{ route('events.index') }}" class="back">← Vsi dogodki</a>

    <article class="detail">
        <p class="when-line">{{ $event->starts_at->translatedFormat('l, j. F Y') }} ob {{ $event->starts_at->format('H:i') }}</p>
        <h1>{{ $event->title }}</h1>
        <dl>
            <dt>Kraj</dt><dd>{{ $event->location }}, {{ $event->town->name }}</dd>
            <dt>Vrsta</dt><dd>{{ $event->category->name }}</dd>
            <dt>Organizator</dt><dd>{{ $event->organizer }}</dd>
            <dt>Vstopnina</dt><dd>{{ $event->is_free ? 'Brezplačno' : 'Plačljivo' }}</dd>
            <dt>Udeleženci</dt><dd>{{ $event->attendees_count }}</dd>
        </dl>
        @if ($event->description)
            <p>{{ $event->description }}</p>
        @endif

        <div class="row">
            @include('partials.join-button', ['event' => $event])
            <a href="{{ route('events.calendar', $event) }}" class="btn ghost">Dodaj v koledar</a>
        </div>

        @if (auth()->id() === $event->user_id)
            <form method="POST" action="{{ route('events.destroy', $event) }}" onsubmit="return confirm('Res izbrišem dogodek?')">
                @csrf
                @method('DELETE')
                <button class="link danger">Izbriši dogodek</button>
            </form>
        @endif
    </article>
@endsection
