@extends('layouts.app')

@section('content')
    <nav class="tabs">
        @foreach (['today' => 'Danes', 'weekend' => 'Ta vikend', 'all' => 'Vsi'] as $key => $label)
            <a href="{{ route('events.index', array_merge($filters, ['view' => $key])) }}"
               class="{{ $view === $key ? 'active' : '' }}">{{ $label }}</a>
        @endforeach
    </nav>

    <form method="GET" action="{{ route('events.index') }}" class="filters">
        <input type="hidden" name="view" value="{{ $view }}">
        <select name="town" onchange="this.form.submit()">
            <option value="">Vsi kraji</option>
            @foreach ($towns as $town)
                <option value="{{ $town->id }}" @selected(($filters['town'] ?? '') == $town->id)>{{ $town->name }}</option>
            @endforeach
        </select>
        <select name="category" onchange="this.form.submit()">
            <option value="">Vse vrste</option>
            @foreach ($categories as $category)
                <option value="{{ $category->id }}" @selected(($filters['category'] ?? '') == $category->id)>{{ $category->name }}</option>
            @endforeach
        </select>
        <label>
            <input type="checkbox" name="free" value="1" @checked($filters['free'] ?? false) onchange="this.form.submit()">
            Samo brezplačni
        </label>
        <noscript><button class="btn">Filtriraj</button></noscript>
    </form>

    <section class="events">
        @forelse ($events as $event)
            @include('partials.event-card', ['event' => $event])
        @empty
            <p class="status">Za izbrane pogoje ni dogodkov.</p>
        @endforelse
    </section>
@endsection
