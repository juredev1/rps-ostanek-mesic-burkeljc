<!doctype html>
<html lang="sl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Vsi lokalni dogodki v Zasavju na enem mestu">
    <title>@yield('title', 'Dogodki Zasavje')</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <header class="top">
        <a href="{{ route('events.index') }}" class="logo">Dogodki Zasavje</a>
        <nav class="user">
            @auth
                <a href="{{ route('events.create') }}" class="btn">+ Objavi dogodek</a>
                <a href="{{ route('account.show') }}" class="link">Moj račun</a>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button class="link">Odjava</button>
                </form>
            @else
                <a href="{{ route('login') }}" class="link">Prijava</a>
                <a href="{{ route('register') }}" class="btn">Registracija</a>
            @endauth
        </nav>
    </header>

    <main>
        @if (session('status'))
            <p class="flash">{{ session('status') }}</p>
        @endif

        @yield('content')
    </main>
</body>
</html>
