@extends('layouts.app')

@section('title', 'Prijava – Dogodki Zasavje')

@section('content')
    <form method="POST" action="{{ route('login') }}" class="form narrow" novalidate>
        @csrf
        <h1>Prijava</h1>

        <label>E-pošta
            <input type="email" name="email" value="{{ old('email') }}" autocomplete="email" required autofocus>
            @error('email') <span class="error">{{ $message }}</span> @enderror
        </label>

        <label>Geslo
            <input type="password" name="password" autocomplete="current-password" required>
            @error('password') <span class="error">{{ $message }}</span> @enderror
        </label>

        <label class="row"><input type="checkbox" name="remember" value="1"> Zapomni si me</label>

        <button class="btn">Prijava</button>
        <p class="small">Še nimaš računa? <a href="{{ route('register') }}">Registriraj se</a></p>
    </form>
@endsection
