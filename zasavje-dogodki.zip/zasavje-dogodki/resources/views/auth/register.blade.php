@extends('layouts.app')

@section('title', 'Registracija – Dogodki Zasavje')

@section('content')
    {{-- novalidate: preverjanje izvede strežnik (RegisterRequest), da so sporočila vedno v slovenščini --}}
    <form method="POST" action="{{ route('register') }}" class="form narrow" novalidate>
        @csrf
        <h1>Registracija</h1>
        <p class="small">Račun potrebuješ za objavo dogodkov in pridružitev. Dogodke si lahko ogledaš tudi brez računa.</p>

        <label>Ime in priimek
            <input name="name" value="{{ old('name') }}" maxlength="80" autocomplete="name" required autofocus>
            @error('name') <span class="error">{{ $message }}</span> @enderror
        </label>

        <label>E-pošta
            <input type="email" name="email" value="{{ old('email') }}" maxlength="120" autocomplete="email" required>
            @error('email') <span class="error">{{ $message }}</span> @enderror
        </label>

        <label>Geslo
            <input type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required>
            <span class="hint">Vsaj 8 znakov, vsaj ena črka in ena številka.</span>
            @error('password') <span class="error">{{ $message }}</span> @enderror
        </label>

        <label>Ponovi geslo
            <input type="password" name="password_confirmation" maxlength="72" autocomplete="new-password" required>
        </label>

        <fieldset>
            <legend>Kaj te zanima? (neobvezno)</legend>
            <div class="checks">
                @foreach ($categories as $category)
                    <label class="row">
                        <input type="checkbox" name="interests[]" value="{{ $category->id }}"
                               @checked(in_array($category->id, old('interests', [])))>
                        {{ $category->name }}
                    </label>
                @endforeach
            </div>
            @error('interests.*') <span class="error">{{ $message }}</span> @enderror
        </fieldset>

        <label class="row">
            <input type="checkbox" name="terms" value="1" @checked(old('terms'))>
            Strinjam se s pogoji uporabe in obdelavo osebnih podatkov.
        </label>
        @error('terms') <span class="error">{{ $message }}</span> @enderror

        <button class="btn">Ustvari račun</button>
        <p class="small">Že imaš račun? <a href="{{ route('login') }}">Prijavi se</a></p>
    </form>
@endsection
