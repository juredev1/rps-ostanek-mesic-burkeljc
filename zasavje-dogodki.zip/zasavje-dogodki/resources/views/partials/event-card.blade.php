<article class="card">
    <div class="when">
        <span class="date">{{ $event->starts_at->translatedFormat('D, j. n.') }}</span>
        <span class="time">{{ $event->starts_at->format('H:i') }}</span>
    </div>
    <div class="body">
        <h3><a href="{{ route('events.show', $event) }}">{{ $event->title }}</a></h3>
        <p class="meta">
            {{ $event->town->name }} · {{ $event->location }} · {{ $event->category->name }}
            @if ($event->is_free) · brezplačno @endif
        </p>
        @if ($event->description)
            <p class="desc">{{ $event->description }}</p>
        @endif
        <div class="actions">
            <span class="count">{{ $event->attendees_count }} se jih pridruži</span>
            @include('partials.join-button', ['event' => $event])
        </div>
    </div>
</article>
