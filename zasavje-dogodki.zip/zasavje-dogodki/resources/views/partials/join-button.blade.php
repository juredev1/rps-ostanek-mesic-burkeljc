@auth
    @if ($event->isJoinedBy(auth()->user()))
        <form method="POST" action="{{ route('events.leave', $event) }}">
            @csrf
            @method('DELETE')
            <button class="btn done" title="Klikni za preklic">Pridružen ✓</button>
        </form>
    @else
        <form method="POST" action="{{ route('events.join', $event) }}">
            @csrf
            <button class="btn">Pridružim se</button>
        </form>
    @endif
@else
    <a href="{{ route('login') }}" class="btn">Pridružim se</a>
@endauth
