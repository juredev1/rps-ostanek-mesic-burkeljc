@extends('layouts.app')

@section('title', 'Moj račun – Dogodki Zasavje')

@section('content')
    <section class="form">
        <h1>Moj račun</h1>
        <dl class="info">
            <dt>Ime in priimek</dt><dd>{{ $user->name }}</dd>
            <dt>E-pošta</dt><dd>{{ $user->email }}</dd>
            <dt>Registriran od</dt><dd>{{ $user->created_at->format('j. n. Y') }}</dd>
            <dt>Objavljeni dogodki</dt><dd>{{ $user->events_count }}</dd>
            <dt>Pridružitve</dt><dd>{{ $user->joined_events_count }}</dd>
        </dl>
    </section>

    <form method="POST" action="{{ route('account.interests') }}" class="form">
        @csrf
        @method('PUT')
        <h2>Interesi</h2>
        <div class="checks">
            @foreach ($categories as $category)
                <label class="row">
                    <input type="checkbox" name="interests[]" value="{{ $category->id }}" @checked(in_array($category->id, $interestIds))>
                    {{ $category->name }}
                </label>
            @endforeach
        </div>
        <div><button class="btn">Shrani interese</button></div>
    </form>

    <form method="POST" action="{{ route('account.password') }}" class="form" novalidate>
        @csrf
        @method('PUT')
        <h2>Spremeni geslo</h2>
        <label>Trenutno geslo
            <input type="password" name="current_password" autocomplete="current-password" required>
            @error('current_password', 'updatePassword') <span class="error">{{ $message }}</span> @enderror
        </label>
        <label>Novo geslo
            <input type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required>
            <span class="hint">Vsaj 8 znakov, vsaj ena črka in ena številka.</span>
            @error('password', 'updatePassword') <span class="error">{{ $message }}</span> @enderror
        </label>
        <label>Ponovi novo geslo
            <input type="password" name="password_confirmation" maxlength="72" autocomplete="new-password" required>
        </label>
        <div><button class="btn">Spremeni geslo</button></div>
    </form>

    <form method="POST" action="{{ route('account.destroy') }}" class="form" novalidate
          onsubmit="return confirm('Res izbrišem račun? Izbrisani bodo tudi tvoji dogodki in pridružitve.')">
        @csrf
        @method('DELETE')
        <h2>Izbriši račun</h2>
        <p class="small">Izbrišejo se vsi tvoji podatki: račun, objavljeni dogodki, pridružitve in interesi.</p>
        <label>Za potrditev vpiši geslo
            <input type="password" name="password" autocomplete="current-password" required>
            @error('password', 'deleteAccount') <span class="error">{{ $message }}</span> @enderror
        </label>
        <div><button class="btn danger-btn">Izbriši račun</button></div>
    </form>
@endsection
