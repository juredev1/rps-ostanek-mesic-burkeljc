<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Interesi uporabnika: katere vrste dogodkov ga zanimajo (razmerje M:N).
    // Uporabimo jih za kasnejša priporočila dogodkov.
    public function up(): void
    {
        Schema::create('category_user', function (Blueprint $table) {
            $table->foreignId('category_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();

            $table->primary(['category_id', 'user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('category_user');
    }
};
