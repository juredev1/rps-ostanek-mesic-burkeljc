<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('events', function (Blueprint $table) {
            $table->id();
            // Tuji ključi
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();       // avtor dogodka
            $table->foreignId('town_id')->constrained()->restrictOnDelete();      // kraj
            $table->foreignId('category_id')->constrained()->restrictOnDelete();  // vrsta dogodka
            // Podatki o dogodku
            $table->string('title', 80);
            $table->string('location', 120);                  // npr. Delavski dom Trbovlje
            $table->decimal('latitude', 9, 6)->nullable();    // za kasnejši zemljevid
            $table->decimal('longitude', 9, 6)->nullable();
            $table->dateTime('starts_at');
            $table->string('organizer', 80);                  // društvo, klub ali posameznik
            $table->text('description')->nullable();
            $table->boolean('is_free')->default(false);
            $table->timestamps();

            $table->index('starts_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('events');
    }
};
