<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Šifrant krajev. Podatke vstavimo kar v migraciji, ker jih aplikacija potrebuje za delovanje.
    public function up(): void
    {
        Schema::create('towns', function (Blueprint $table) {
            $table->id();
            $table->string('name', 40)->unique();
        });

        DB::table('towns')->insert([
            ['name' => 'Trbovlje'],
            ['name' => 'Hrastnik'],
            ['name' => 'Zagorje ob Savi'],
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('towns');
    }
};
