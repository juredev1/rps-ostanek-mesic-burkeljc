<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    // Šifrant vrst dogodkov (koncert, šport ...)
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('name', 40)->unique();
        });

        DB::table('categories')->insert([
            ['name' => 'Koncert'],
            ['name' => 'Šport'],
            ['name' => 'Razstava'],
            ['name' => 'Delavnica'],
            ['name' => 'Prostovoljstvo'],
            ['name' => 'Drugo'],
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('categories');
    }
};
