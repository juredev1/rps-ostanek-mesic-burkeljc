<?php

namespace App\Providers;

use Illuminate\Support\Carbon;
use Illuminate\Support\ServiceProvider;
use Illuminate\Validation\Rules\Password;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Imena dni in mesecev v slovenščini (npr. "sob., 24. 10.")
        Carbon::setLocale(config('app.locale'));

        // Pravila za gesla na enem mestu (registracija in sprememba gesla):
        // vsaj 8 znakov, vsaj ena črka in ena številka, največ 72 znakov
        // (bcrypt upošteva le prvih 72 bajtov gesla).
        Password::defaults(fn () => Password::min(8)->max(72)->letters()->numbers());
    }
}
