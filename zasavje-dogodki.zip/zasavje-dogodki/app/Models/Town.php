<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** Kraj (šifrant): Trbovlje, Hrastnik, Zagorje ob Savi */
class Town extends Model
{
    public $timestamps = false;

    protected $fillable = ['name'];

    public function events(): HasMany
    {
        return $this->hasMany(Event::class);
    }
}
