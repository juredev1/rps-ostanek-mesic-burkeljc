<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

/** Vrsta dogodka (šifrant): Koncert, Šport, Razstava ... */
class Category extends Model
{
    public $timestamps = false;

    protected $fillable = ['name'];

    public function events(): HasMany
    {
        return $this->hasMany(Event::class);
    }

    /** Uporabniki, ki so to vrsto dogodkov izbrali med interese */
    public function interestedUsers(): BelongsToMany
    {
        return $this->belongsToMany(User::class);
    }
}
