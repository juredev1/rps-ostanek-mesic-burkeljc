<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Support\Carbon;

class Event extends Model
{
    protected $fillable = [
        'town_id', 'category_id', 'title', 'location', 'latitude', 'longitude',
        'starts_at', 'organizer', 'description', 'is_free',
    ];

    protected function casts(): array
    {
        return [
            'starts_at' => 'datetime',
            'is_free' => 'boolean',
            'latitude' => 'float',
            'longitude' => 'float',
        ];
    }

    /** Uporabnik, ki je dogodek objavil */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function town(): BelongsTo
    {
        return $this->belongsTo(Town::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    /** Uporabniki, ki so se dogodku pridružili */
    public function attendees(): BelongsToMany
    {
        return $this->belongsToMany(User::class)->withTimestamps();
    }

    /** Dogodki, ki se še niso končali (upoštevamo tudi tiste, ki so se začeli pred kratkim) */
    public function scopeUpcoming(Builder $query): Builder
    {
        return $query->where('starts_at', '>=', now()->subHours(6));
    }

    public function scopeToday(Builder $query): Builder
    {
        return $query->whereBetween('starts_at', [today(), today()->endOfDay()]);
    }

    /** Najbližja sobota in nedelja (če je danes vikend, ta vikend) */
    public function scopeThisWeekend(Builder $query): Builder
    {
        $saturday = match (true) {
            today()->isSaturday() => today(),
            today()->isSunday() => today()->subDay(),
            default => today()->next(Carbon::SATURDAY),
        };

        return $query->whereBetween('starts_at', [$saturday, $saturday->copy()->addDay()->endOfDay()]);
    }

    /** Filtri iz obrazca: kraj, vrsta (ID iz šifranta), samo brezplačni */
    public function scopeFilter(Builder $query, array $filters): Builder
    {
        return $query
            ->when($filters['town'] ?? null, fn ($q, $town) => $q->where('town_id', (int) $town))
            ->when($filters['category'] ?? null, fn ($q, $category) => $q->where('category_id', (int) $category))
            ->when($filters['free'] ?? null, fn ($q) => $q->where('is_free', true));
    }

    public function isJoinedBy(?User $user): bool
    {
        if (! $user) {
            return false;
        }

        return $this->relationLoaded('attendees')
            ? $this->attendees->contains($user)
            : $this->attendees()->whereKey($user->id)->exists();
    }
}
