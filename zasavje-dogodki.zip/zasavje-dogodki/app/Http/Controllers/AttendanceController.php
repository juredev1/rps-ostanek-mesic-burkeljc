<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    /** Gumb "Pridružim se" */
    public function store(Request $request, Event $event): RedirectResponse
    {
        // syncWithoutDetaching prepreči, da bi se isti uporabnik pridružil dvakrat
        $event->attendees()->syncWithoutDetaching([$request->user()->id]);

        return back()->with('status', 'Pridružil si se dogodku »'.$event->title.'«.');
    }

    /** Preklic pridružitve */
    public function destroy(Request $request, Event $event): RedirectResponse
    {
        $event->attendees()->detach($request->user()->id);

        return back()->with('status', 'Pridružitev je preklicana.');
    }
}
