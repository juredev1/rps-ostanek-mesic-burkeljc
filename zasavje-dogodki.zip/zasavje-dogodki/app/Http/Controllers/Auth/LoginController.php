<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class LoginController extends Controller
{
    public function create(): View
    {
        return view('auth.login');
    }

    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();

        $request->session()->regenerate(); // nov ID seje po prijavi

        return redirect()->intended(route('events.index'))->with('status', 'Prijava je uspela.');
    }

    public function destroy(Request $request): RedirectResponse
    {
        Auth::logout();
        $request->session()->invalidate();      // izbriše podatke seje
        $request->session()->regenerateToken(); // nov žeton CSRF

        return redirect()->route('events.index')->with('status', 'Odjava je uspela.');
    }
}
