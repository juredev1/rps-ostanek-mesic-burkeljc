<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\RegisterRequest;
use App\Models\Category;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class RegisterController extends Controller
{
    public function create(): View
    {
        return view('auth.register', [
            'categories' => Category::orderBy('id')->get(),
        ]);
    }

    public function store(RegisterRequest $request): RedirectResponse
    {
        $data = $request->validated();

        // Uporabnik in njegovi interesi se shranijo skupaj ali pa nič (transakcija)
        $user = DB::transaction(function () use ($data) {
            $user = User::create([
                'name' => $data['name'],
                'email' => $data['email'],
                'password' => $data['password'],   // cast 'hashed' v modelu User ga zgosti z bcrypt
                'terms_accepted_at' => now(),
            ]);

            $user->interests()->sync($data['interests'] ?? []);

            return $user;
        });

        Auth::login($user);
        $request->session()->regenerate(); // nov ID seje prepreči prevzem seje (session fixation)

        return redirect()->route('events.index')->with('status', 'Račun je ustvarjen. Dobrodošel, '.$user->name.'!');
    }
}
