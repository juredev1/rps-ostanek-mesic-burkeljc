<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Event;
use App\Models\Town;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\View\View;

class EventController extends Controller
{
    /** Seznam dogodkov s pogledi Danes / Ta vikend / Vsi in filtri */
    public function index(Request $request): View
    {
        $view = in_array($request->query('view'), ['today', 'weekend', 'all'], true)
            ? $request->query('view')
            : 'today';

        $filters = $request->only(['town', 'category', 'free']);

        $events = Event::query()
            ->upcoming()
            ->when($view === 'today', fn ($q) => $q->today())
            ->when($view === 'weekend', fn ($q) => $q->thisWeekend())
            ->filter($filters)
            ->with(['town', 'category'])
            ->withCount('attendees')
            ->with(['attendees' => fn ($q) => $q->whereKey($request->user()?->id ?? 0)])
            ->orderBy('starts_at')
            ->get();

        return view('events.index', [
            'events' => $events,
            'view' => $view,
            'filters' => $filters,
            'towns' => Town::orderBy('id')->get(),
            'categories' => Category::orderBy('id')->get(),
        ]);
    }

    public function show(Event $event): View
    {
        $event->load(['town', 'category'])->loadCount('attendees');

        return view('events.show', ['event' => $event]);
    }

    public function create(): View
    {
        return view('events.create', [
            'towns' => Town::orderBy('id')->get(),
            'categories' => Category::orderBy('id')->get(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        // Sporočila o napakah so v lang/sl/validation.php
        $data = $request->validate([
            'title' => ['required', 'string', 'max:80'],
            'town_id' => ['required', 'integer', 'exists:towns,id'],
            'location' => ['required', 'string', 'max:120'],
            'category_id' => ['required', 'integer', 'exists:categories,id'],
            'starts_at' => ['required', 'date', 'after:now'],
            'organizer' => ['required', 'string', 'max:80'],
            'description' => ['nullable', 'string', 'max:500'],
        ]);

        $data['is_free'] = $request->boolean('is_free');

        $event = $request->user()->events()->create($data);

        return redirect()->route('events.show', $event)->with('status', 'Dogodek je objavljen.');
    }

    public function destroy(Request $request, Event $event): RedirectResponse
    {
        // Dogodek lahko izbriše le tisti, ki ga je objavil
        abort_unless($event->user_id === $request->user()->id, 403);

        $event->delete();

        return redirect()->route('events.index')->with('status', 'Dogodek je izbrisan.');
    }

    /** Datoteka .ics: doda dogodek v koledar na telefonu z opomnikom 1 uro prej */
    public function calendar(Event $event): Response
    {
        $start = $event->starts_at->copy()->utc();
        $end = $start->copy()->addHours(2);
        $escape = fn (?string $text) => str_replace(["\\", ';', ',', "\r\n", "\n"], ["\\\\", '\;', '\,', '\n', '\n'], $text ?? '');

        $ics = implode("\r\n", [
            'BEGIN:VCALENDAR',
            'VERSION:2.0',
            'PRODID:-//Dogodki Zasavje//SL',
            'BEGIN:VEVENT',
            'UID:event-'.$event->id.'@dogodki-zasavje',
            'DTSTAMP:'.now()->utc()->format('Ymd\THis\Z'),
            'DTSTART:'.$start->format('Ymd\THis\Z'),
            'DTEND:'.$end->format('Ymd\THis\Z'),
            'SUMMARY:'.$escape($event->title),
            'LOCATION:'.$escape($event->location.', '.$event->town->name),
            'DESCRIPTION:'.$escape($event->description),
            'BEGIN:VALARM',
            'TRIGGER:-PT1H',
            'ACTION:DISPLAY',
            'DESCRIPTION:'.$escape($event->title),
            'END:VALARM',
            'END:VEVENT',
            'END:VCALENDAR',
        ])."\r\n";

        return response($ics, 200, [
            'Content-Type' => 'text/calendar; charset=utf-8',
            'Content-Disposition' => 'attachment; filename="dogodek-'.$event->id.'.ics"',
        ]);
    }
}
