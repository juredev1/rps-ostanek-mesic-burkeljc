# Dogodki Zasavje

Spletna aplikacija s skupnim koledarjem vseh lokalnih dogodkov v Zasavju (Trbovlje, Hrastnik, Zagorje ob Savi).
Uporabnik vidi, kaj se dogaja danes in ta vikend, filtrira po kraju in vrsti dogodka ter se dogodku pridruži.
Organizator po prijavi v nekaj korakih objavi svoj dogodek.

Ekipa: Jure Ostanek, Matic Burkeljc, Harun Mešić · Mentor: Žan Rajšek

## Tehnologije

- PHP 8.2+ in [Laravel 12](https://laravel.com/docs/12.x)
- Blade predloge, navaden CSS (`public/css/app.css`)
- Podatkovna baza: MySQL (npr. XAMPP s phpMyAdmin)
- Git + GitHub

## Zagon

Potrebuješ PHP 8.2+, [Composer](https://getcomposer.org), MySQL in Git. Najlažje je z XAMPP (PHP + MySQL + phpMyAdmin) in Composerjem.

1. V XAMPP Control Panel zaženi **Apache** in **MySQL**.
2. V phpMyAdmin (http://localhost/phpmyadmin) ustvari bazo `zasavje_dogodki` z naborom `utf8mb4_unicode_ci`.
3. V mapi projekta zaženi:

```bash
git clone <naslov-repozitorija>
cd zasavje-dogodki
composer install
cp .env.example .env          # na Windows: copy .env.example .env
php artisan key:generate
php artisan migrate --seed    # ustvari bazo in testne dogodke
php artisan serve
```

Aplikacija se odpre na http://localhost:8000.

Nastavitve baze so v datoteki `.env` (privzeto uporabnik `root` brez gesla, kot pri XAMPP):

```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=zasavje_dogodki
DB_USERNAME=root
DB_PASSWORD=
```

Testni račun: `organizator@example.com`, geslo `geslo123`.
Bazo s svežimi testnimi podatki ponastaviš z `php artisan migrate:fresh --seed`.

> Če si bazo ustvaril s prejšnjo različico projekta, zaženi `php artisan migrate:fresh --seed`,
> ker se je zgradba tabel spremenila (kraji in vrste dogodkov sta zdaj ločeni tabeli).

## Testi

```bash
php artisan test
```

Testi tečejo na začasni bazi v pomnilniku (SQLite), zato ne spreminjajo podatkov v MySQL.

38 testov v treh datotekah:

- `tests/Feature/AuthTest.php` – registracija, prijava, odjava, zgoščena gesla, pravila gesel, omejitev poskusov prijave
- `tests/Feature/AccountTest.php` – stran Moj račun, sprememba gesla, interesi, izbris računa
- `tests/Feature/EventTest.php` – ogled, filtri, objava, pridružitev, brisanje, datoteka za koledar

## Podatkovni model

ER-diagram je v `docs/er-diagram.png`, izvorno besedilo pa v `docs/er-diagram.mmd`
(urejaš ga na https://mermaid.live).

| Tabela | Namen |
| --- | --- |
| `users` | uporabniški računi (geslo samo zgoščeno z bcrypt) |
| `events` | dogodki; tuji ključi `user_id`, `town_id`, `category_id` |
| `towns` | šifrant krajev |
| `categories` | šifrant vrst dogodkov |
| `event_user` | pridružitve (M:N med uporabniki in dogodki) |
| `category_user` | interesi uporabnika (M:N med uporabniki in vrstami) |
| `sessions` | seje prijavljenih uporabnikov in gostov |

## Varnost računov

- Gesla se shranijo zgoščena z algoritmom bcrypt (cast `hashed` v modelu `User`), nikoli kot čisto besedilo.
- Pravila za geslo (vsaj 8 znakov, črka in številka, največ 72) so na enem mestu v `AppServiceProvider`.
- Po 5 neuspešnih prijavah v minuti se prijava za isto e-pošto in IP začasno zaklene (`LoginRequest`).
- Po prijavi se ustvari nov ID seje, ob odjavi se seja izbriše; vsi obrazci imajo žeton CSRF.
- Napaka pri prijavi ne razkrije, ali račun z vpisano e-pošto obstaja.
- Sprememba gesla in izbris računa zahtevata trenutno geslo.

## Struktura (naše datoteke)

```
routes/web.php                                 vse poti (URL-ji) aplikacije
app/Models/Event.php                           model dogodka, filtri Danes / Ta vikend / kraj / vrsta
app/Models/User.php                            uporabnik, objavljeni in pridruženi dogodki, interesi
app/Models/Town.php, Category.php              šifranta krajev in vrst dogodkov
app/Http/Controllers/EventController.php       seznam, prikaz, objava, brisanje, datoteka .ics
app/Http/Controllers/AttendanceController.php  Pridružim se / preklic
app/Http/Controllers/Auth/                     registracija, prijava, odjava
app/Http/Requests/Auth/                        preverjanje obrazcev za registracijo in prijavo, omejitev poskusov
app/Http/Controllers/AccountController.php     Moj račun: interesi, sprememba gesla, izbris računa
app/Providers/AppServiceProvider.php           pravila za gesla
database/migrations/                           tabele users, towns, categories, events, event_user, category_user
database/seeders/DatabaseSeeder.php            testni podatki
resources/views/                               Blade predloge (layouts, events, auth, partials)
public/css/app.css                             videz (najprej za telefon)
lang/sl/                                       slovenska sporočila o napakah
docs/                                          ER-diagram
tests/Feature/                                 testi
```

## Poti

| Metoda | URL | Opis | Prijava |
| --- | --- | --- | --- |
| GET | `/` | Seznam dogodkov (`?view=today/weekend/all`, `town`, `category`, `free`) | ne |
| GET | `/dogodki/{id}` | Podrobnosti dogodka | ne |
| GET | `/dogodki/{id}/koledar.ics` | Dodaj v koledar (opomnik 1 uro prej) | ne |
| GET/POST | `/registracija`, `/prijava` | Ustvari račun, prijava | ne |
| POST | `/odjava` | Odjava | da |
| GET | `/racun` | Moj račun | da |
| PUT | `/racun/interesi` | Shrani interese | da |
| PUT | `/racun/geslo` | Spremeni geslo (zahteva trenutno geslo) | da |
| DELETE | `/racun` | Izbriši račun (zahteva geslo) | da |
| GET | `/dogodki/nov` | Obrazec za objavo | da |
| POST | `/dogodki` | Shrani dogodek | da |
| DELETE | `/dogodki/{id}` | Izbriši (samo avtor) | da |
| POST/DELETE | `/dogodki/{id}/pridruzi` | Pridružim se / preklic | da |

## Delo z Gitom

- `main` je vedno delujoča različica.
- Za vsako funkcionalnost nova veja, npr. `feature/zemljevid`, nato pull request in pregled sošolca.
- Kratka sporočila commitov v slovenščini, npr. `Dodan filter po kraju`.
- Datoteke `.env` in mape `vendor/` ne nalagamo na GitHub (sta v `.gitignore`).
