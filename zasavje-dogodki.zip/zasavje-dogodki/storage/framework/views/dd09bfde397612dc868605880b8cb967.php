<?php $__env->startSection('title', 'Prijava – Dogodki Zasavje'); ?>

<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('login')); ?>" class="form narrow" novalidate>
        <?php echo csrf_field(); ?>
        <h1>Prijava</h1>

        <label>E-pošta
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="email" required autofocus>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label>Geslo
            <input type="password" name="password" autocomplete="current-password" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label class="row"><input type="checkbox" name="remember" value="1"> Zapomni si me</label>

        <button class="btn">Prijava</button>
        <p class="small">Še nimaš računa? <a href="<?php echo e(route('register')); ?>">Registriraj se</a></p>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jure\Downloads\zasavje-dogodki\resources\views/auth/login.blade.php ENDPATH**/ ?>