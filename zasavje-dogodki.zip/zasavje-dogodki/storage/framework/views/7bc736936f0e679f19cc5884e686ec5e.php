<!doctype html>
<html lang="sl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Vsi lokalni dogodki v Zasavju na enem mestu">
    <title><?php echo $__env->yieldContent('title', 'Dogodki Zasavje'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <header class="top">
        <a href="<?php echo e(route('events.index')); ?>" class="logo">Dogodki Zasavje</a>
        <nav class="user">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('events.create')); ?>" class="btn">+ Objavi dogodek</a>
                <a href="<?php echo e(route('account.show')); ?>" class="link">Moj račun</a>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="link">Odjava</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="link">Prijava</a>
                <a href="<?php echo e(route('register')); ?>" class="btn">Registracija</a>
            <?php endif; ?>
        </nav>
    </header>

    <main>
        <?php if(session('status')): ?>
            <p class="flash"><?php echo e(session('status')); ?></p>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html>
<?php /**PATH C:\Users\Jure\Downloads\zasavje-dogodki\resources\views/layouts/app.blade.php ENDPATH**/ ?>