<?php $__env->startSection('title', 'Registracija – Dogodki Zasavje'); ?>

<?php $__env->startSection('content'); ?>
    
    <form method="POST" action="<?php echo e(route('register')); ?>" class="form narrow" novalidate>
        <?php echo csrf_field(); ?>
        <h1>Registracija</h1>
        <p class="small">Račun potrebuješ za objavo dogodkov in pridružitev. Dogodke si lahko ogledaš tudi brez računa.</p>

        <label>Ime in priimek
            <input name="name" value="<?php echo e(old('name')); ?>" maxlength="80" autocomplete="name" required autofocus>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label>E-pošta
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" maxlength="120" autocomplete="email" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label>Geslo
            <input type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required>
            <span class="hint">Vsaj 8 znakov, vsaj ena črka in ena številka.</span>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </label>

        <label>Ponovi geslo
            <input type="password" name="password_confirmation" maxlength="72" autocomplete="new-password" required>
        </label>

        <fieldset>
            <legend>Kaj te zanima? (neobvezno)</legend>
            <div class="checks">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="row">
                        <input type="checkbox" name="interests[]" value="<?php echo e($category->id); ?>"
                               <?php if(in_array($category->id, old('interests', []))): echo 'checked'; endif; ?>>
                        <?php echo e($category->name); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php $__errorArgs = ['interests.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </fieldset>

        <label class="row">
            <input type="checkbox" name="terms" value="1" <?php if(old('terms')): echo 'checked'; endif; ?>>
            Strinjam se s pogoji uporabe in obdelavo osebnih podatkov.
        </label>
        <?php $__errorArgs = ['terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button class="btn">Ustvari račun</button>
        <p class="small">Že imaš račun? <a href="<?php echo e(route('login')); ?>">Prijavi se</a></p>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jure\Downloads\zasavje-dogodki\resources\views/auth/register.blade.php ENDPATH**/ ?>