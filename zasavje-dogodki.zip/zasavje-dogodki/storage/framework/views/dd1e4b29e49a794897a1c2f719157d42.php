<?php $__env->startSection('content'); ?>
    <nav class="tabs">
        <?php $__currentLoopData = ['today' => 'Danes', 'weekend' => 'Ta vikend', 'all' => 'Vsi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('events.index', array_merge($filters, ['view' => $key]))); ?>"
               class="<?php echo e($view === $key ? 'active' : ''); ?>"><?php echo e($label); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>

    <form method="GET" action="<?php echo e(route('events.index')); ?>" class="filters">
        <input type="hidden" name="view" value="<?php echo e($view); ?>">
        <select name="town" onchange="this.form.submit()">
            <option value="">Vsi kraji</option>
            <?php $__currentLoopData = $towns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $town): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($town->id); ?>" <?php if(($filters['town'] ?? '') == $town->id): echo 'selected'; endif; ?>><?php echo e($town->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="category" onchange="this.form.submit()">
            <option value="">Vse vrste</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php if(($filters['category'] ?? '') == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label>
            <input type="checkbox" name="free" value="1" <?php if($filters['free'] ?? false): echo 'checked'; endif; ?> onchange="this.form.submit()">
            Samo brezplačni
        </label>
        <noscript><button class="btn">Filtriraj</button></noscript>
    </form>

    <section class="events">
        <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('partials.event-card', ['event' => $event], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="status">Za izbrane pogoje ni dogodkov.</p>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jure\Downloads\zasavje-dogodki\resources\views/events/index.blade.php ENDPATH**/ ?>