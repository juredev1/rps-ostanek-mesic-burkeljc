<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Event;
use App\Models\Town;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class EventTest extends TestCase
{
    use RefreshDatabase;

    private function makeEvent(User $user, array $overrides = []): Event
    {
        return $user->events()->create(array_merge([
            'title' => 'Testni dogodek',
            'town_id' => Town::where('name', 'Trbovlje')->value('id'),
            'location' => 'Delavski dom',
            'category_id' => Category::where('name', 'Koncert')->value('id'),
            'starts_at' => now()->addDays(2),
            'organizer' => 'Društvo',
            'is_free' => true,
        ], $overrides));
    }

    public function test_guest_can_see_events(): void
    {
        $this->makeEvent(User::factory()->create());

        $this->get('/?view=all')->assertOk()->assertSee('Testni dogodek');
    }

    public function test_events_can_be_filtered_by_town(): void
    {
        $user = User::factory()->create();
        $this->makeEvent($user, ['title' => 'Dogodek v Trbovljah']);
        $this->makeEvent($user, ['title' => 'Dogodek v Hrastniku', 'town_id' => Town::where('name', 'Hrastnik')->value('id')]);

        $hrastnik = Town::where('name', 'Hrastnik')->value('id');

        $this->get('/?view=all&town='.$hrastnik)
            ->assertOk()
            ->assertSee('Dogodek v Hrastniku')
            ->assertDontSee('Dogodek v Trbovljah');
    }

    public function test_event_with_unknown_town_is_rejected(): void
    {
        $this->actingAs(User::factory()->create())->post('/dogodki', [
            'title' => 'Dogodek',
            'town_id' => 999,
            'location' => 'Dom kulture',
            'category_id' => Category::first()->id,
            'starts_at' => now()->addWeek()->format('Y-m-d\TH:i'),
            'organizer' => 'Klub',
        ])->assertSessionHasErrors('town_id');
    }

    public function test_guest_cannot_open_create_form(): void
    {
        $this->get('/dogodki/nov')->assertRedirect('/prijava');
    }

    public function test_user_can_create_event(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->post('/dogodki', [
            'title' => 'Nov koncert',
            'town_id' => Town::where('name', 'Hrastnik')->value('id'),
            'location' => 'Dom kulture',
            'category_id' => Category::where('name', 'Koncert')->value('id'),
            'starts_at' => now()->addWeek()->format('Y-m-d\TH:i'),
            'organizer' => 'Klub',
        ])->assertRedirect();

        $this->assertDatabaseHas('events', ['title' => 'Nov koncert', 'user_id' => $user->id]);
    }

    public function test_event_in_past_is_rejected(): void
    {
        $this->actingAs(User::factory()->create())->post('/dogodki', [
            'title' => 'Stari dogodek',
            'town_id' => Town::where('name', 'Hrastnik')->value('id'),
            'location' => 'Dom kulture',
            'category_id' => Category::where('name', 'Koncert')->value('id'),
            'starts_at' => now()->subDay()->format('Y-m-d\TH:i'),
            'organizer' => 'Klub',
        ])->assertSessionHasErrors('starts_at');
    }

    public function test_user_can_join_only_once(): void
    {
        $user = User::factory()->create();
        $event = $this->makeEvent($user);

        $this->actingAs($user)->post("/dogodki/{$event->id}/pridruzi");
        $this->actingAs($user)->post("/dogodki/{$event->id}/pridruzi");

        $this->assertSame(1, $event->attendees()->count());
    }

    public function test_only_author_can_delete_event(): void
    {
        $event = $this->makeEvent(User::factory()->create());

        $this->actingAs(User::factory()->create())
            ->delete("/dogodki/{$event->id}")
            ->assertForbidden();
    }

    public function test_calendar_file_has_reminder(): void
    {
        $event = $this->makeEvent(User::factory()->create());

        $this->get("/dogodki/{$event->id}/koledar.ics")
            ->assertOk()
            ->assertHeader('Content-Type', 'text/calendar; charset=utf-8')
            ->assertSee('TRIGGER:-PT1H');
    }
}
