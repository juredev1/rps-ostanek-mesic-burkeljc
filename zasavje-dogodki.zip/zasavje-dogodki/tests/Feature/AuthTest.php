<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AuthTest extends TestCase
{
    use RefreshDatabase;

    private function validRegistration(array $overrides = []): array
    {
        return array_merge([
            'name' => 'Ana Novak',
            'email' => 'ana@example.com',
            'password' => 'skrivnost123',
            'password_confirmation' => 'skrivnost123',
            'terms' => '1',
        ], $overrides);
    }

    // ---------- Registracija ----------

    public function test_registration_form_shows_required_fields(): void
    {
        $this->get('/registracija')
            ->assertOk()
            ->assertSee('name="name"', false)
            ->assertSee('name="email"', false)
            ->assertSee('name="password"', false)
            ->assertSee('name="password_confirmation"', false)
            ->assertSee('name="terms"', false)
            ->assertSee('name="_token"', false); // zaščita CSRF
    }

    public function test_user_can_register_and_is_logged_in(): void
    {
        $this->post('/registracija', $this->validRegistration())
            ->assertRedirect('/');

        $this->assertAuthenticated();
        $this->assertDatabaseHas('users', ['email' => 'ana@example.com', 'name' => 'Ana Novak']);
        $this->assertNotNull(User::first()->terms_accepted_at);
    }

    public function test_password_is_stored_hashed_not_as_plain_text(): void
    {
        $this->post('/registracija', $this->validRegistration());

        $stored = DB::table('users')->where('email', 'ana@example.com')->value('password');

        $this->assertNotSame('skrivnost123', $stored);
        $this->assertStringNotContainsString('skrivnost123', $stored);
        $this->assertStringStartsWith('$2y$', $stored); // oznaka algoritma bcrypt
        $this->assertTrue(Hash::check('skrivnost123', $stored));
    }

    public function test_same_password_gives_different_hashes(): void
    {
        User::create(['name' => 'Ana', 'email' => 'ana@example.com', 'password' => 'skrivnost123']);
        User::create(['name' => 'Bor', 'email' => 'bor@example.com', 'password' => 'skrivnost123']);

        $hashes = DB::table('users')->pluck('password');

        $this->assertCount(2, $hashes);
        $this->assertNotSame($hashes[0], $hashes[1]); // vsako geslo ima svojo naključno sol
    }

    public function test_email_is_saved_in_lowercase(): void
    {
        $this->post('/registracija', $this->validRegistration(['email' => '  Ana@Example.COM ']));

        $this->assertDatabaseHas('users', ['email' => 'ana@example.com']);
    }

    public function test_invalid_email_is_rejected(): void
    {
        foreach (['ana', 'ana@example', 'ana@exa mple.si'] as $email) {
            $this->post('/registracija', $this->validRegistration(['email' => $email]))
                ->assertSessionHasErrors(['email' => 'Vnesi veljaven e-poštni naslov.']);
        }

        $this->assertDatabaseCount('users', 0);
    }

    public function test_email_must_be_unique(): void
    {
        User::factory()->create(['email' => 'ana@example.com']);

        $this->post('/registracija', $this->validRegistration(['email' => 'ANA@example.com']))
            ->assertSessionHasErrors(['email' => 'Račun s to e-pošto že obstaja.']);

        $this->assertGuest();
    }

    public function test_weak_passwords_are_rejected(): void
    {
        foreach (['kratko1', 'samocrke', '12345678'] as $weak) {
            $this->post('/registracija', $this->validRegistration([
                'password' => $weak,
                'password_confirmation' => $weak,
            ]))->assertSessionHasErrors('password');
        }

        $this->assertDatabaseCount('users', 0);
    }

    public function test_password_confirmation_must_match(): void
    {
        $this->post('/registracija', $this->validRegistration(['password_confirmation' => 'drugacno123']))
            ->assertSessionHasErrors(['password' => 'Gesli se ne ujemata.']);
    }

    public function test_terms_must_be_accepted(): void
    {
        $data = $this->validRegistration();
        unset($data['terms']);

        $this->post('/registracija', $data)->assertSessionHasErrors('terms');
        $this->assertDatabaseCount('users', 0);
    }

    public function test_required_fields_have_slovenian_messages(): void
    {
        $this->post('/registracija', [])
            ->assertSessionHasErrors([
                'name' => 'Polje »ime in priimek« je obvezno.',
                'email' => 'Polje »e-pošta« je obvezno.',
                'password' => 'Polje »geslo« je obvezno.',
            ]);
    }

    public function test_interests_are_saved_on_registration(): void
    {
        $ids = Category::whereIn('name', ['Koncert', 'Šport'])->pluck('id')->all();

        $this->post('/registracija', $this->validRegistration(['interests' => $ids]));

        $this->assertEqualsCanonicalizing($ids, User::first()->interests()->pluck('categories.id')->all());
    }

    public function test_password_is_never_flashed_back_to_the_form(): void
    {
        $this->post('/registracija', $this->validRegistration(['terms' => null]));

        $this->assertNull(session()->getOldInput('password'));
        $this->assertSame('ana@example.com', session()->getOldInput('email'));
    }

    // ---------- Prijava ----------

    public function test_user_can_log_in_with_correct_password(): void
    {
        $user = User::factory()->create(['email' => 'ana@example.com', 'password' => 'skrivnost123']);

        $this->post('/prijava', ['email' => 'ANA@example.com', 'password' => 'skrivnost123'])
            ->assertRedirect('/');

        $this->assertAuthenticatedAs($user);
    }

    public function test_wrong_password_and_unknown_email_give_the_same_message(): void
    {
        User::factory()->create(['email' => 'ana@example.com', 'password' => 'skrivnost123']);

        $this->post('/prijava', ['email' => 'ana@example.com', 'password' => 'napacno123'])
            ->assertSessionHasErrors(['email' => 'E-pošta ali geslo ni pravilno.']);

        $this->post('/prijava', ['email' => 'nihce@example.com', 'password' => 'napacno123'])
            ->assertSessionHasErrors(['email' => 'E-pošta ali geslo ni pravilno.']);

        $this->assertGuest();
    }

    public function test_login_is_locked_after_five_failed_attempts(): void
    {
        User::factory()->create(['email' => 'ana@example.com', 'password' => 'skrivnost123']);

        for ($i = 0; $i < 5; $i++) {
            $this->post('/prijava', ['email' => 'ana@example.com', 'password' => 'napacno123']);
        }

        // Tudi s pravilnim geslom se zdaj ne more prijaviti, dokler zaklepanje ne poteče
        $response = $this->post('/prijava', ['email' => 'ana@example.com', 'password' => 'skrivnost123']);

        $response->assertSessionHasErrors('email');
        $this->assertStringContainsString('Preveč neuspešnih poskusov', session('errors')->first('email'));
        $this->assertGuest();
    }

    public function test_session_id_changes_after_login(): void
    {
        User::factory()->create(['email' => 'ana@example.com', 'password' => 'skrivnost123']);

        $this->get('/prijava');
        $before = session()->getId();

        $this->post('/prijava', ['email' => 'ana@example.com', 'password' => 'skrivnost123']);

        $this->assertNotSame($before, session()->getId());
    }

    public function test_remember_me_sets_remember_token(): void
    {
        $user = User::factory()->create(['email' => 'ana@example.com', 'password' => 'skrivnost123', 'remember_token' => null]);

        $this->post('/prijava', ['email' => 'ana@example.com', 'password' => 'skrivnost123', 'remember' => '1']);

        $this->assertNotNull($user->fresh()->remember_token);
    }

    public function test_logged_in_user_is_redirected_away_from_login_and_register(): void
    {
        $this->actingAs(User::factory()->create());

        $this->get('/prijava')->assertRedirect('/');
        $this->get('/registracija')->assertRedirect('/');
    }

    public function test_user_can_log_out(): void
    {
        $this->actingAs(User::factory()->create())
            ->post('/odjava')
            ->assertRedirect('/');

        $this->assertGuest();
    }

    public function test_logout_requires_post_with_csrf_token(): void
    {
        // Odjava prek povezave (GET) ni mogoča
        $this->actingAs(User::factory()->create())->get('/odjava')->assertStatus(405);
    }
}
