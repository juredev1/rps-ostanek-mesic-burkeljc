<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Town;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AccountTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_cannot_open_account_page(): void
    {
        $this->get('/racun')->assertRedirect('/prijava');
    }

    public function test_user_sees_account_page(): void
    {
        $user = User::factory()->create(['name' => 'Ana Novak']);

        $this->actingAs($user)->get('/racun')->assertOk()->assertSee('Ana Novak')->assertSee($user->email);
    }

    public function test_password_change_requires_current_password(): void
    {
        $user = User::factory()->create(['password' => 'skrivnost123']);

        $this->actingAs($user)->put('/racun/geslo', [
            'current_password' => 'napacno123',
            'password' => 'novogeslo456',
            'password_confirmation' => 'novogeslo456',
        ])->assertSessionHasErrorsIn('updatePassword', ['current_password' => 'Geslo ni pravilno.']);

        $this->assertTrue(Hash::check('skrivnost123', $user->fresh()->password));
    }

    public function test_user_can_change_password(): void
    {
        $user = User::factory()->create(['password' => 'skrivnost123']);

        $this->actingAs($user)->put('/racun/geslo', [
            'current_password' => 'skrivnost123',
            'password' => 'novogeslo456',
            'password_confirmation' => 'novogeslo456',
        ])->assertSessionHasNoErrors();

        $this->assertTrue(Hash::check('novogeslo456', $user->fresh()->password));
    }

    public function test_new_password_must_differ_from_current(): void
    {
        $user = User::factory()->create(['password' => 'skrivnost123']);

        $this->actingAs($user)->put('/racun/geslo', [
            'current_password' => 'skrivnost123',
            'password' => 'skrivnost123',
            'password_confirmation' => 'skrivnost123',
        ])->assertSessionHasErrorsIn('updatePassword', 'password');
    }

    public function test_user_can_update_interests(): void
    {
        $user = User::factory()->create();
        $ids = Category::whereIn('name', ['Razstava', 'Delavnica'])->pluck('id')->all();

        $this->actingAs($user)->put('/racun/interesi', ['interests' => $ids]);

        $this->assertEqualsCanonicalizing($ids, $user->interests()->pluck('categories.id')->all());
    }

    public function test_deleting_account_requires_password_and_removes_data(): void
    {
        $user = User::factory()->create(['password' => 'skrivnost123']);
        $user->interests()->attach(Category::first());
        $event = $user->events()->create([
            'title' => 'Moj dogodek',
            'town_id' => Town::first()->id,
            'category_id' => Category::first()->id,
            'location' => 'Dom',
            'starts_at' => now()->addDay(),
            'organizer' => 'Jaz',
        ]);

        $this->actingAs($user)->delete('/racun', ['password' => 'napacno123'])
            ->assertSessionHasErrorsIn('deleteAccount', 'password');
        $this->assertDatabaseHas('users', ['id' => $user->id]);

        $this->actingAs($user)->delete('/racun', ['password' => 'skrivnost123'])->assertRedirect('/');

        $this->assertGuest();
        $this->assertDatabaseMissing('users', ['id' => $user->id]);
        $this->assertDatabaseMissing('events', ['id' => $event->id]);        // CASCADE
        $this->assertDatabaseMissing('category_user', ['user_id' => $user->id]);
    }
}
